create table NgoDetails (detailId number primary key,orgName varchar2(30),address varchar2(30),scheme varchar2(30),achievements varchar2(30),uuid varchar2(30),
projectInCharge varchar2(30),position varchar2(30),email varchar2(30),MobileNo number(10),noOfStaff number(10),regCerti Blob,dateOfReg Date,courseList varchar2(30),status varchar2(30));


create table Users (userId number primary key,username varchar2(30),
email varchar2(30),phoneNumber number(10),password varchar2(30));
// intialize variable for scheme module check uncheck
var research=[];
var swadhar=[];
var ujjawala=[];
var creche=[];

//Datepicker
$(document).on('focus', '#datepicker', function (){
    $('#datepicker').datepicker({
        dateFormat: 'dd/mm/yyyy',
        changeMonth: true,
        changeYear: true,
        autoclose: true
    });
});

$(function(){
    var len = $('#committee_member_dob, #employee_dob, #office_bearers_dob, #approvalrejectiondate, #date_approval, #pab_date, #approvalrejectiondt, #nipccdapprovalrejectiondt, #pabdate, #cr_employee_dop, #caw_start, #caw_end, #start_date, #end_date, #dbtsearch, #dbtmonth').length;
    if(len > 0){
        $("#committee_member_dob").datepicker({
            dateFormat: 'dd/mm/yyyy',
            changeMonth: true,
            changeYear: true,
            autoclose: true
        });
        $("#employee_dob").datepicker({
            dateFormat: 'dd/mm/yyyy',
            changeMonth: true,
            changeYear: true,
            autoclose: true
        });
        $("#office_bearers_dob").datepicker({
            dateFormat: 'dd/mm/yyyy',
            changeMonth: true,
            changeYear: true,
            autoclose: true
        });
        $("#approvalrejectiondate").datepicker({
            dateFormat: 'dd/mm/yyyy',
            changeMonth: true,
            changeYear: true,
            autoclose: true
        });
        $("#date_approval").datepicker({
            dateFormat: 'dd/mm/yyyy',
            changeMonth: true,
            changeYear: true,
            autoclose: true
        });
        $("#pab_date").datepicker({
            dateFormat: 'dd/mm/yyyy',
            changeMonth: true,
            changeYear: true,
            autoclose: true
        });

        $("#approvalrejectiondt").datepicker({
            dateFormat: 'dd/mm/yyyy',
            changeMonth: true,
            changeYear: true,
            autoclose: true
        });
        $("#nipccdapprovalrejectiondt").datepicker({
            dateFormat: 'dd/mm/yyyy',
            changeMonth: true,
            changeYear: true,
            autoclose: true
        });

        $("#pabdate").datepicker({
            dateFormat: 'dd/mm/yyyy',
            changeMonth: true,
            changeYear: true,
            autoclose: true
        });

        //creche datepicker
        $("#cr_employee_dop").datepicker({
            dateFormat: 'dd/mm/yyyy',
            changeMonth: true,
            changeYear: true,
            autoclose: true
        });

        //Scheme Start Date
        $("#caw_start").datepicker({
            dateFormat: 'dd/mm/yyyy',
            changeMonth: true,
            changeYear: true,
            autoclose: true
        });

        //Scheme End Date
        $("#caw_end").datepicker({
            dateFormat: 'dd/mm/yyyy',
            changeMonth: true,
            changeYear: true,
            autoclose: true
        });

        //Start Date
        $("#start_date").datepicker({
            dateFormat: 'dd/mm/yyyy',
            changeMonth: true,
            changeYear: true,
            autoclose: true
        });

        //End Date
        $("#end_date").datepicker({
            dateFormat: 'dd/mm/yyyy',
            changeMonth: true,
            changeYear: true,
            autoclose: true
        });
        //DBT
        $("#dbtsearch").daterangepicker({
            locale: {
                format: 'YYYY/MM/DD'
            }
        });
        //DBT Monthly Report start date & end date
        $("#dbtmonth").datepicker({
            dateFormat: 'dd/mm/yyyy',
            changeMonth: true,
            changeYear: true,
            autoclose: true,
            minViewMode:'months',
            viewMode: 'months'
        });
    }
    
    /*** DBT Month Reports ***/
    $('#dbtmonfyr').on('change', function(){
        var xhrFyr = $.trim($(this).val());
        xhrFyr = xhrFyr.split('-');
        
        /** Start & End Date **/
        var start_date='',end_date='';
        start_date = '01/04/'+xhrFyr[0];
        end_date = '31/03/'+xhrFyr[1];
        
        var date_obj = new Date();
        var current_year = date_obj.getFullYear();
        
        if(xhrFyr[1] > current_year){
            var date_objs = new Date(date_obj.getFullYear(), date_obj.getMonth() + 1, 0);
            end_date = date_objs.getDate()+'/'+date_objs.getMonth()+'/'+date_objs.getFullYear();
        }
        
        //Set New Start and end date
        $("#dbtmonth").datepicker('setStartDate',start_date).datepicker('setEndDate',end_date).datepicker('update',start_date).val(start_date);
    });
});

//for Names
function onlyAlphaNumeric(e, t)
{
    try
    {
        if (window.event)
        {
            var charCode = window.event.keyCode;
        } else if (e)
        {
            var charCode = e.which;
        } else
        {
            return true;
        }
        if ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 123) || (charCode > 47 && charCode < 58) || (charCode == 32) || charCode == 0 || charCode == 8)
            return true;
        else
            return false;
    } catch (err)
    {
        alert(err.Description);
    }
}
function onlyRegister(e, t)
{
    try
    {
        if (window.event)
        {
            var charCode = window.event.keyCode;
        } else if (e)
        {
            var charCode = e.which;
        } else
        {
            return true;
        }

        if (charCode == 8 || (charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 123) || (charCode > 47 && charCode < 58) || (charCode == 32))
            return true;
        else
            return false;
    } catch (err)
    {
        alert(err.Description);
    }
}

function textBrac(e, t)
{
    try
    {
        if (window.event)
        {
            var charCode = window.event.keyCode;
        } else if (e)
        {
            var charCode = e.which;
        } else
        {
            return true;
        }

        if (charCode == 8 || (charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 123) || (charCode == 32) || (charCode == 40) || (charCode == 41))
            return true;
        else
            return false;
    } catch (err)
    {
        alert(err.Description);
    }
}

//For Alphabets only
function onlyAlpha(e, t)
{

    try
    {
        console.log(e);
        console.log(e.which);
        if (window.event)
        {
            var charCode = window.event.keyCode;
        } else if (e)
        {
            var charCode = e.which;
        } else
        {
            return true;
        }


        if ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 123) || (charCode == 32) || charCode == 0 || charCode == 8)
            return true;
        else
            return false;
    } catch (err)
    {
        alert(err.Description);
    }
}

//for Numbers only
function onlyNumeric(e, t)
{
    try
    {
        var charCode = e.keyCode || e.which;
        
        if (charCode == 8 || (charCode > 31 && charCode < 58) || charCode == 9)
            return true;
        else
            return false;
    } catch (err)
    {
        alert(err.Description);
    }
}

function isNumberKey(evt)
      {
         var charCode = (evt.which) ? evt.which : event.keyCode
         if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;

         return true;
      }

//Plot
function onlyPlot(e, t)
{
    try
    {
        if (window.event)
        {
            var charCode = window.event.keyCode;
        } else if (e)
        {
            var charCode = e.which;
        } else
        {
            return true;
        }
        if (charCode == 8 || charCode == 32 || (charCode >= 47 && charCode < 58) || (charCode == 45) || (charCode == 35))
            return true;
        else
            return false;
    } catch (err)
    {
        alert(err.Description);
    }
}

// Email Validation	onblur
function checkEmail(str)
{
    var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    if (!re.test(str))
        alert("Please enter a valid email address");
    return false;
}



//PAN onblur
function checkPAN(str)
{
    var pan = /^([A-Z]){5}([0-9]){4}([A-Z]){1}?$/;
    if (!pan.test(str)) {
        alert("Please enter a valid pan no");
        return false;
    }
}

// Pin Code on blur

function checkPin(str)
{
    var pin = /^[1-9][0-9]{5}$/;
    if ((!pin.test(str))) {
        alert("Please enter a pin no");
        return false;
    }

}



function onlyAlphaSpeCha(e, t)
{
    try
    {
        console.log(e);
        console.log(e.which);
        if (window.event)
        {
            var charCode = window.event.keyCode;
        } else if (e)
        {
            var charCode = e.which;
        } else
        {
            return true;
        }


        if ((charCode > 63 && charCode < 91) || (charCode > 96 && charCode < 123) || (charCode == 32) || (charCode == 44) || (charCode > 45 && charCode < 59) || (charCode > 37 && charCode < 42) || charCode == 0 || charCode == 8 || charCode == 13 || charCode == 45 || charCode == 95)
            return true;
        else
            return false;
    } catch (err)
    {
        alert(err.Description);
    }
}

function onlyAlphaSpeChaforpassword(e, t)
{
    try
    {
        console.log(e);
        console.log(e.which);
        if (window.event)
        {
            var charCode = window.event.keyCode;
        } else if (e)
        {
            var charCode = e.which;
        } else
        {
            return true;
        }


        if ((charCode > 63 && charCode < 91) || (charCode > 96 && charCode < 123) || charCode == 32 || charCode == 37 || charCode == 64 || charCode == 35 || charCode == 36 || (charCode > 47 && charCode < 58) || charCode == 0 || charCode == 8)
            return true;
        else
            return false;
    } catch (err)
    {
        alert(err.Description);
    }
}


//for Numbers With Special Charcter(.) only
function onlyNumericwithspeclchar(e, t)
{
    try
    {
        if (window.event)
        {
            var charCode = window.event.keyCode;
        } else if (e)
        {
            var charCode = e.which;
        } else
        {
            return true;
        }
        if (charCode == 8 || (charCode > 47 && charCode < 58) || charCode == 46)
            return true;
        else
            return false;
    } catch (err)
    {
        alert(err.Description);
    }
}

//for AlphaNumeric With Special Charcter(_) only
function onlyAlphaNumericwithspeclchar(e, t)
{
    try
    {
        if (window.event)
        {
            var charCode = window.event.keyCode;
        } else if (e)
        {
            var charCode = e.which;
        } else
        {
            return true;
        }
        if ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 123) || (charCode > 44 && charCode < 58) || (charCode == 32) || charCode == 0 || charCode == 8 || charCode == 95 || charCode == 45)
            return true;
        else
            return false;
    } catch (err)
    {
        alert(err.Description);
    }
}



/****Function Start For Rejection ****/

function abc1(id,detail=''){
    var ids = id.value;
    $("#userrejectdid").val(ids);
    $("#userdetaildivs").html(detail);
}

function submittrejctdata(recid) {
    $("#rejectasonblank").text('');

    var rejectreason = $("#rejectreason").val();
    if (rejectreason != '') {
        var formDetails = $('#rejection_reason');
        $.ajax({
            type: "POST",
            url: baseURL + 'users/rejectionreason',
            data: formDetails.serialize(),
            dataType: "json ",
            success: function (data) {


                if (data.status == true) {

                    swal({
                        title: "Rejection Remark Submitted",
                        text: data.message,
                        type: "success",
                        confirmButtonText: "OK",
                    },
                            function () {
                                location.href = location.href;
                            });

                }

            },
            sending: function (file, xhr, formData) {
                formData.append(token_name, csrf_token);
            },
        });
        $("#rejectasonblank").css('display', 'none');
    } else {
        $("#rejectasonblank").text("Reject Reason Should not be blank");
        $("#rejectreason").focus();
        $("#approvreasonblank").show();
    }

}
/****Function End ****/


/****Function Start For Approval ****/

function abc(id, role, detail='') {
    var ids = id.value;
    if (role == 3)
    {
        $("#chkschemes_2").hide();
    } else
    {
        $("#chkschemes_2").show();
    }
    $('#role').val(role);
    $("#userapprovedid").val(ids);
    $("#userdetaildiv").html(detail);
}

function submitapprvtdata() {

    var role = $('#role').val();
    role = $.trim(role);

    $("#approv_schemepremssion").text('');
    $("#approvreasonblank").text('');

    var counter = 0;
    var matches = new Array();
    $('.scheme_details').each(function () {
        if (role == 3) {
            if (this.value != 2) {
                if (this.checked) {
                    matches.push(this.value);
                }
            }
        } else {
            if (this.checked) {
                matches.push(this.value);
            }
        }
    });
    var apprvreason = $("#apprvreason").val();

    if (matches.length > 0 && apprvreason != '') {
        var counter1 = 0;
        var counter2 = 0;
        var counter3 = 0;
        var counter4 = 0;
        var counter5 = 0;
        var counter6 = 0;

        if ($.inArray('1', matches) >= 0) {
            $('.step_moduleprms1').each(function () {
                if (this.checked) {
                    counter1++;
                }
            });
            if (counter1 > 0) {
                counter++;
            } else {
                alert("Please select atleast one module of step scheme!");
                return false;
            }
        }

        if (role != 3) {
            if ($.inArray('2', matches) >= 0) {
                $('.resrch_moduleprms1').each(function () {
                    if (this.checked) {
                        counter2++;
                    }
                });
                if (counter2 > 0) {
                    counter++;
                } else {
                    alert("Please select atleast one module of Research scheme!");
                    return false;
                }
            }
        }

        if ($.inArray('3', matches) >= 0) {
            $('.swdhr_moduleprms1').each(function () {
                if (this.checked) {
                    counter3++;
                }
            });
            if (counter3 > 0) {
                counter++;
            } else {
                alert("Please select atleast one module of Swadhar scheme!");
                return false;
            }
        }
        if ($.inArray('4', matches) >= 0) {
            $('.ujwla_moduleprms1').each(function () {
                if (this.checked) {
                    counter4++;
                }
            });
            if (counter4 > 0) {
                counter++;
            } else {
                alert("Please select atleast one module of Ujjawala scheme!");
                return false;
            }
        }
        if ($.inArray('5', matches) >= 0) {
            $('.creche_moduleprms1').each(function () {
                if (this.checked) {
                    counter5++;
                }
            });
            if (counter5 > 0) {
                counter++;
            } else {
                alert("Please select atleast one module of Creche scheme!");
                return false;
            }
        }

        if ($.inArray('6', matches) >= 0) {
            $('.icds_moduleprms1').each(function () {
                if (this.checked) {
                    counter6++;
                }
            });
            if (counter6 > 0) {
                counter++;
            } else {
                alert("Please select atleast one module of ICDS scheme!");
                return false;
            }
        }

        if (counter == matches.length)
        {
            var formDetails = $('#approved_reason');
            $.ajax({
                type: "POST",
                url: baseURL + 'users/approvereason',
                data: formDetails.serialize(),
                dataType: "json ",
                success: function (data) {
                    if (data.status == true) {

                        swal({
                            title: "Approve Remark Submitted",
                            text: data.message,
                            type: "success",
                            confirmButtonText: "OK",
                        },
                                function () {
                                    location.href = location.href;
                                });

                    }

                },
                sending: function (file, xhr, formData) {
                    formData.append(token_name, csrf_token);
                },
            });
        } else
        {
            alert('Please select atleast one module of selected schemes!');
            return false;
        }
        $("#approv_schemepremssion").css('display', 'none');
        $("#approvreasonblank").css('display', 'none');
    } else
    {
        if(apprvreason == ''){
            $("#approvreasonblank").text("Approve Reason Should not be blank");
            $("#apprvreason").focus();
            $("#approvreasonblank").show();
        }
        $("#approv_schemepremssion").text("Please Select Atleast One Scheme");
        $("#approv_schemepremssion").show();
        $("#schemecheckall").focus();
        return false;
    }

}

/****Function Start For Password & Comfirm password Encryption ****/
function getConfirmPass() {
    var passwordvalue = $('#newpassword').val();
    passwordvalue = $.trim(passwordvalue);

    var confirmpasswordvalue = $('#confirm_password').val();
    confirmpasswordvalue = $.trim(confirmpasswordvalue);

    if (passwordvalue != '')
    {
        passwordvalue = md5(passwordvalue);
        $('#newpassword').val(salt + '@#1' + passwordvalue);
    }

    if (confirmpasswordvalue != '')
    {
        confirmpasswordvalue = md5(confirmpasswordvalue);
        $('#confirm_password').val(salt + '@#1' + confirmpasswordvalue);
    }

}

/****Function End ****/

/****Function Start For Pattern check in Password & Comfirm password****/

function validatePassword()
{
    var pwd = $("#newpassword").val();
    pwd = $.trim(pwd);

    var pattern = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{6,16}$/;
    if (pattern.test(pwd))
    {
        return true;
    } else
    {
        $('.newpassword').text('Password should contain at least one lowercase letter, one uppercase letter, one numeric digit, and one special character (@#$%) and length should be beween 6 to 16');
        $("#newpassword").val('').focus();
        return false;
    }
}
/****Function End  ****/


/****Function Start For Pattern check in Comfirm password ****/

function validateCnfrmPassword()
{
    var cnfrmpwd = '';
    if ($('#cpassword').length > 0)
    {
        cnfrmpwd = $("#cpassword").val();
        $('.cpassword').text('');
    } else
    {
        cnfrmpwd = $("#confirm_password").val();
    }
    cnfrmpwd = $.trim(cnfrmpwd);

    var pattern = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{6,16}$/;
    if (pattern.test(cnfrmpwd))
    {
        return true;
    } else
    {
        if ($('#cpassword').length > 0)
        {
            $('.cpassword').text('Confirm Password should contain at least one lowercase letter, one uppercase letter, one numeric digit, and one special character (@#$%) and length should be beween 6 to 16');
            $("#cpassword").val('').focus();
        } else
        {
            alert('Confirm Password should contain at least one lowercase letter, one uppercase letter, one numeric digit, and one special character (@#$%) and length should be beween 6 to 16');
            $("#confirm_password").val('').focus();
        }
        return false;
    }
}

/****Function End****/


/****Function Start For Pattern check For Email ****/

function validateEmail()
{
    var email = $("#stateUesremail").val();
    email = $.trim(email);
    email = email.toLowerCase();
    

    var pattern = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/;

    if (email != '')
    {
        if (pattern.test(email)) {
            
            $("#stateUesremail").val(email);
            checkemailonuserrole(email);
            return true;
        } else {
            $("#stateUesremail").val('');
            $("#stateUesremail").next().html('Please Enter valid email');
            return false;
        }
    } else {
        alert('Please enter email.');
        return false;
    }
}

/****Function End****/


/***** Function Start for validating the address ******/
function addressValidation(e)
{
    try
    {
        if (window.event)
        {
            var charCode = window.event.keyCode;
        } else if (e)
        {
            var charCode = e.which;
        } else
        {
            return true;
        }

        if ((charCode == 8) || (charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 123) || (charCode == 32) ||
                (charCode == 46) || (charCode == 45) || (charCode == 44) || (charCode > 47 && charCode < 58))
            return true;
        else
            return false;
    } catch (err)
    {
        alert(err.Description);
    }
}
/**** Function End ****/


/****Function Start For Inactive User ****/

function inactiveuserdata(recid) {
    var id = recid;
    var wcdNgo = $("#wcdNgo").val();
    $.ajax({
        type: "POST",
        url: baseURL + 'users/inactivateduser',
        data: 'id=' + id + '&wcdNgo=' + wcdNgo + '&' + token_name + '=' + csrf_token,
        dataType: "json ",
        success: function (data) {
            if (data.status == true) {
                swal({
                    title: "Inactive Successfully",
                    text: data.message,
                    type: "success",
                    confirmButtonText: "OK",
                },
                function () {
                    location.href = location.href;
                });
            }
        },
        sending: function (file, xhr, formData) {
            formData.append(token_name, csrf_token);
        },
    });
}
/****Function End For Inactive User ****/

//Active the registered user
function activeuserdata(recid, flag = '') {
    var id = recid;
    var wcdNgo = $("#wcdNgo").val();
    $.ajax({
        type: "POST",
        url: baseURL + 'users/inactivateduser',
        data: 'id=' + id + '&wcdNgo=' + wcdNgo + '&' + token_name + '=' + csrf_token + '&flag=' + flag,
        dataType: "json ",
        success: function (data) {
            if (data.status == true) {
                var title = ''
                if (flag != '') {
                    title = 'Active successfully.'
                } else {
                    title = 'Inactive successfully.'
                }
                
                swal({
                    title: title,
                    text: data.message,
                    type: "success",
                    confirmButtonText: "OK",
                },
                function () {
                    location.reload();
                });
            }
        },
        sending: function (file, xhr, formData) {
            formData.append(token_name, csrf_token);
        },
    });
}

$(document).ready(function () {
    // Show aciton upon row hover
    $('.table tbody tr').hover(function () {
        $(this).find('.table-action-hide a').animate({opacity: 3});
    }, function () {
        jQuery(this).find('.table-action-hide a').animate({opacity: 0});
    });
     /*******SHOW PASSWORD VISIBLE ON KEYPRESS**********/
    
    $("#psecrtkn").click(function(){
        var passval = document.getElementById("password");
        var passlen= $("#password").val().length;
        if(passlen > 0){
        if (passval.type === "password") {
            passval.type = "text";
            $(this).attr('title', 'Hide Password').removeClass('fa fa-eye').addClass('fa fa-eye-slash');
        } else {
            passval.type = "password";
            $(this).attr('title', 'Show Password').removeClass('fa fa-eye-slash').addClass('fa fa-eye');
        }
        }
    });
});

/****Function Start For Edit user ****/

function updatedata() {

    $("#userid_error").text('');
    $("#username_error").text('');
    $("#useremailid_error").text('');
    $("#usermoblno_error").text('');

    var counter = 0;
    var matches = new Array();
    $('.scheme_details').each(function () {
        if (this.checked) {
            matches.push(this.value);
        }
    });
    
    var modules = new Array();
    $('.module_details').each(function () {
        if (this.checked) {
            modules.push(this.value);
        }
    });
    
    var user_id = $('#user_id').val();
    var username = $('#username').val();
    var uesremail = $('#uesremail').val();
    var mobile = $('#mobile').val();

    if ((matches.length > 0 || modules.length > 0) && user_id != '' && username != '' && uesremail != '' && mobile != '') {
        
       /* if(matches.length > 0){
           
            var counter2 = 0;
            var counter3 = 0;
            var counter4 = 0;
            var counter5 = 0;
            
            if ($.inArray('2', matches) >= 0) {
                $('.resrch_moduleprms').each(function () {
                    if (this.checked) {
                        counter2++;
                    }
                });

                if (counter2 > 0) {
                    counter++;
                } else {
                    alert("Please select atleast one module of Research scheme!");
                    return false;
                }
            }
            if ($.inArray('3', matches) >= 0) {
                $('.swdhr_moduleprms').each(function () {
                    if (this.checked) {
                        counter3++;
                    }
                });

                if (counter3 > 0) {
                    counter++;
                } else {
                    alert("Please select atleast one module of Swadhar scheme!");
                    return false;
                }
            }
            if ($.inArray('4', matches) >= 0) {
                $('.ujwla_moduleprms').each(function () {
                    if (this.checked) {
                        counter4++;
                    }
                });
                if (counter4 > 0) {
                    counter++;
                } else {
                    alert("Please select atleast one module of Ujjawala scheme!");
                    return false;
                }
            }
            if ($.inArray('5', matches) >= 0) {
                $('.creche_moduleprms').each(function () {
                    if (this.checked) {
                        counter5++;
                    }
                });
                if (counter5 > 0) {
                    counter++;
                } else {
                    alert("Please select atleast one module of Creche scheme!");
                    return false;
                }
            }

        }*/
        
        if (counter == matches.length || modules.length > 0) {
            var formDetails = $('#edit_user');
            $.ajax({
                type: "POST",
                url: baseURL + 'admin/updatepermission',
                data: formDetails.serialize(),
                dataType: 'JSON',
                success: function (data) {
                    if (data.status == true) {
                        swal({
                            title: username+" Details Updated Successfully",
                            text: data.message,
                            type: "success",
                            confirmButtonText: "OK",
                        },
                        function () {
                            //location.href = baseURL + 'admin/activeuserlist';
                            location.reload();
                        });
                    }
                    else
                    {
                        $('#msg').html(data.messages);
                    }
                },
                sending: function (file, xhr, formData) {
                    formData.append(token_name, csrf_token);
                }
            });
        } else {
            alert('Please select at least one scheme or one module for permission access.');
            return false;
        }

        $("#userid_error").css('display', 'none');
        $("#username_error").css('display', 'none');
        $("#useremailid_error").css('display', 'none');
        $("#usermoblno_error").css('display', 'none');
    } else {
        if (user_id == '') {
            $("#userid_error").text("User id Should not be blank");
            $("#user_id").focus();
            $("#userid_error").show();
        } else if (username == '') {
            $("#username_error").text("User Name Should not be blank");
            $("#username").focus();
            $("#username_error").show();
        } else if (uesremail == '') {
            $("#useremailid_error").text("Email Id Should not be blank");
            $("#uesremail").focus();
            $("#useremailid_error").show();
        } else if (mobile == '') {
            $("#usermoblno_error").text("Mobile No Should not be blank");
            $("#mobile").focus();
            $("#usermoblno_error").show();
        }
        alert("Please select at least one scheme or one module for permission access.");
        return false;
    }
}
/****Function End ****/

/****Function Start For Pattern check For Email ****/

function validateEmailss()
{
    var email = $("#uesremail").val();
    email = $.trim(email);

    var pattern = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/;
    if (pattern.test(email))
    {
        return true;
    } else
    {
        alert('Please Enter valid email');
        return false;
    }
}

/****Function End****/

function checkAlphaNumeric(object)
{
    var regExp = /^[0-9a-zA-Z]+$/;
    var pan = $('#' + object).val();
    pan = $.trim(pan);

    if (pan.match(regExp) == false)
    {
        alert('Pan card number alpha numeric only.');
        $('#' + object).focus();
        return false;
    }
}

/****Function Start For Show hide schmes permission for Edit user page****/

function schemetype(recid) {
    var id = recid;
    var schemes = document.getElementById("schemes_" + id).checked;

    if(schemes == true){
        if(id == '1'){
            $("#step").show();
            $("#schemes_" + id).attr('checked', true);
        } else if (id == '2') {
            $("#research_checkbox").show();
            $("#research").show();
            $("#schemes_" + id).attr('checked', true);
        } else if (id == '3') {
            $("#swadhar_checkbox").show();
            $("#swadhar").show();
            $("#schemes_" + id).attr('checked', true);
        } else if (id == '4') {
            $("#ujjawala_checkbox").show();
            $("#ujjawala").show();
            $("#schemes_" + id).attr('checked', true);
        } else if (id == '5') {
            $("#creche_checkbox").show();
            $("#creche").show();
            $("#schemes_" + id).attr('checked', true);
        } else if (id == '6') {
            $("#icds").show();
            $("#schemes_" + id).attr('checked', true);
        }
    } else {
        if (id == '1') {
            $("#step").hide();
            $('#step input').prop('checked', false);
            $("#schemes_" + id).removeAttr('checked');
            $(".step_moduleprms").removeAttr('checked');
            $('#stepcheckall').prop('checked', false);
        } else if (id == '2') {
            if(research.length==0)
            {
            $("#research_checkbox").hide();
            $("#research").hide();
            $('#research input').prop('checked', false);
            $("#schemes_" + id).removeAttr('checked');
            $(".resrch_moduleprms").removeAttr('checked');
            $('#resrchcheckall').prop('checked', false);
            $('.research_permission').html('');
            }
            else{
                
                document.getElementById("schemes_" + id).checked="checked";
                swal({
                    title: "Are you sure to uncheck research scheme permission?",
                    text: "Please uncheck research scheme module",
                    type: "info",
                    confirmButtonText: "OK",
                },
                function () {
                    //location.href = baseURL + 'admin/editActiveUser';
                    //location.reload();
                });
            }
        } else if (id == '3') {
            $("#swadhar_checkbox").hide();
            $("#swadhar").hide();
            $('#swadhar input').prop('checked', false);
            $("#schemes_" + id).removeAttr('checked');
            $(".swdhr_moduleprms").removeAttr('checked');
            $('#swdhrcheckall').prop('checked', false);
            $('.swadhar_permission').html('');
        } else if (id == '4') {
            $("#ujjawala_checkbox").hide();
            $("#ujjawala").hide();
            $('#ujjawala input').prop('checked', false);
            $("#schemes_" + id).removeAttr('checked');
            $(".ujwla_moduleprms").removeAttr('checked');
            $('#ujjwlacheckall').prop('checked', false);
            $('.ujjawala_permission').html('');
        } else if (id == '5') {
            $("#creche_checkbox").hide();
            $("#creche").hide();
            $('#creche input').prop('checked', false);
            $("#schemes_" + id).removeAttr('checked');
            $(".creche_moduleprms").removeAttr('checked');
            $('#crechecheckall').prop('checked', false);
            $('.creche_permission').html('');
        }
    }
}

function setSchem(type,id)
{
   // alert(type);
    if(type="research")
    {
        research.push(id)
    }
    else if(type="swadhar")
    {

    }
    else if(type='ujjawala')
    {

    }
    else if(type="creche")
    {

    }
}

function delSchem(type,id,el)
{
    if(type="research")
    {
        console.log(el.checked);
        if(el.checked)
        {
            research.push(id);
            console.log(research);
        }
        else
        {
            research.splice(research.indexOf(id),1);
            console.log(research);
        }
        
        if(research.length==0)
        {

            document.getElementById("schemes_2").checked="";
        }
        else
        {
            document.getElementById("schemes_2").checked="checked";
        }
       
    }
    else if(type="swadhar")
    {

    }
    else if(type='ujjawala')
    {

    }
    else if(type="creche")
    {

    }
}

/***Functions Start for Select All Functionality***/
function modulecheck_all() {

    var checked = false;
    var aa = document.getElementsByClassName('module_details');
    if (document.getElementById("modulecheckall").checked == true)
    {
        checked = true
    } else
    {
        checked = false
    }
    for (var i = 0; i < aa.length; i++) {
        aa[i].checked = checked;
    }
}


/***Functions Start for Select All Functionality***/
function schemecheck_all(){
    if($('#schemecheckall').prop('checked') == true){
        $('.scheme_details').prop('checked','checked').each(function(){
            var data_flag = $(this).attr('data-flag');
            data_flag = $.trim(data_flag);
            
            var data_module = $(this).attr('data-module');
            data_module = $.trim(data_module);
            
            var scheme_name = data_module.split('_');
            scheme_name = uc_first_character(scheme_name[0]);
            scheme_name = scheme_name.toLowerCase();
            
            $('#'+data_flag).show();
            $('#'+data_module).prop('checked', false);
            $('.'+scheme_name+'_perm').prop('disabled', true);
        });
    }else{
        $('.scheme_details').prop('checked', false).each(function(){
            var data_flag = $(this).attr('data-flag');
            data_flag = $.trim(data_flag);
            
            var data_module = $(this).attr('data-module');
            data_module = $.trim(data_module);

            var scheme_name = data_module.split('_');
            scheme_name = uc_first_character(scheme_name[0]);
            scheme_name = scheme_name.toLowerCase();
            
            var module_check_count=0;
            $('.'+scheme_name+'_perm').each(function(){
                if($(this).prop("checked") == true){
                    module_check_count++;
                }
            });
            if(module_check_count > 0){
                $('#schemecheckall').prop('checked', 'checked');
                $(this).prop('checked', 'checked');
                swal({
                    title: "Are you sure to uncheck "+scheme_name+" scheme permission?",
                    text: "Please uncheck "+scheme_name+" scheme module",
                    type: "info",
                    confirmButtonText: "OK",
                });
            }else{
                $('#'+data_flag).hide();
                $('#'+data_module).prop('checked', false);
            }
        });
    }
}

/***Functions Start for Select All Functionality***/
function checkedstepAll() {

    var checked = false;
    var aa = document.getElementsByClassName('step_moduleprms');
    if (document.getElementById("stepcheckall").checked == true)
    {
        checked = true
    } else
    {
        checked = false
    }
    for (var i = 0; i < aa.length; i++) {
        aa[i].checked = checked;
    }
}

//******IMPORTANT********function also use for search application module on officer dashboard******IMPORTANT********
function checkresr_all() {

    var checked = false;
    var aa = document.getElementsByClassName('resrch_moduleprms');
    if (document.getElementById("resrchcheckall").checked == true)
    {
        checked = true
    } else
    {
        checked = false
    }
    for (var i = 0; i < aa.length; i++) {
        aa[i].checked = checked;
    }
}

function checkswdhr_all() {

    var checked = false;
    var aa = document.getElementsByClassName('swdhr_moduleprms');
    if (document.getElementById("swdhrcheckall").checked == true)
    {
        checked = true
    } else
    {
        checked = false
    }
    for (var i = 0; i < aa.length; i++) {
        aa[i].checked = checked;
    }
}

function checkujjwla_all() {

    var checked = false;
    var aa = document.getElementsByClassName('ujwla_moduleprms');
    if (document.getElementById("ujjwlacheckall").checked == true)
    {
        checked = true
    } else
    {
        checked = false
    }
    for (var i = 0; i < aa.length; i++) {
        aa[i].checked = checked;
    }
}

function checkcreche_all() {

    var checked = false;
    var aa = document.getElementsByClassName('creche_moduleprms');
    if (document.getElementById("crechecheckall").checked == true)
    {
        checked = true
    } else
    {
        checked = false
    }
    for (var i = 0; i < aa.length; i++) {
        aa[i].checked = checked;
    }
}

function checkicds_all() {
    var checked = false;
    var aa = document.getElementsByClassName('icds_moduleprms');
    if (document.getElementById("icdscheckall").checked == true) {
        checked = true
    } else {
        checked = false
    }
    for (var i = 0; i < aa.length; i++) {
        aa[i].checked = checked;
    }
}


/****Function End for Select All Functionality****/


/****Function End ****/


/****Function Start For Show hide schmes permission in Approve user popup****/
$(document).ready(function () {
    $("#step1, #research1, #swadhar1, #ujjawala1, #creche1, #icds1").hide();

    /* main js for scheme banner */
    if($('#myCarousel').length > 0){
        $('#myCarousel').carousel({
            interval: 50
        });
        $('.fdi-Carousel .item').each(function () {
            var next = $(this).next();
            if (!next.length) {
                next = $(this).siblings(':first');
            }
            next.children(':first-child').clone().appendTo($(this));

            if (next.next().length > 0) {
                next.next().children(':first-child').clone().appendTo($(this));
            } else {
                $(this).siblings(':first').children(':first-child').clone().appendTo($(this));
            }
        });
    }
    
    //Checked or Unchecked each schemes
    if($('.scheme_details').length > 0){
        var schemes_length = $('.scheme_details').length;
        $('.scheme_details').on('click', function(){
            //Schemes Checked Count
            var schemes_count = 0;
            
            var data_flag = $(this).attr('data-flag');
            data_flag = $.trim(data_flag);

            var data_module = $(this).attr('data-module');
            data_module = $.trim(data_module);

            var scheme_name = data_module.split('_');
            scheme_name = uc_first_character(scheme_name[0]);
            scheme_name = scheme_name.toLowerCase();

            var module_check_count = 0;
            $('.'+scheme_name+'_perm').each(function(){
                if($(this).prop("checked") == true){
                    module_check_count++;
                }
            });

            //Show & Hide Scheme Modules
            if($(this).prop('checked') == false){
                if(module_check_count > 0){
                    $(this).prop('checked', 'checked');
                    swal({
                        title: "Are you sure to uncheck "+scheme_name+" scheme permission?",
                        text: "Please uncheck "+scheme_name+" scheme module",
                        type: "info",
                        confirmButtonText: "OK",
                    });
                }else{
                    if(data_flag != ''){
                        $('#'+data_flag).hide();
                        $('#'+data_module).prop('checked', false);
                    }
                }
            }else{
                if(data_flag != ''){
                    $('#'+data_flag).show();
                    $('.'+scheme_name+'_perm').prop('disabled', true);
                }
            }
            
            //Scheme Checked Count
            $('.scheme_details').each(function(){
                if($(this).prop('checked') == true){
                    schemes_count++;
                }
            });
            
            if(schemes_length == schemes_count){
                $('#schemecheckall').prop('checked', true);
            }else{
                $('#schemecheckall').prop('checked', false);
            }
        });
    }
    
    //Enable or Disabled schemes modules
    $('.enable_disable_module').on('click', function(){
        var data_flag = $(this).attr('data-flag');
        data_flag = $.trim(data_flag);
        if($(this).prop('checked') == true){
            $('.'+data_flag).prop('disabled', false);
        }else{
            $('.'+data_flag).prop('disabled', true);
        }
    });
    
    //Checked Or Unchecked all schemes modules
    if($('.module_check_all').length > 0){
        $('.module_check_all').on('click', function(){
            var data_flag = $(this).attr('data-flag');
            data_flag = $.trim(data_flag);
            if($(this).prop('checked') == true){
                $('.'+data_flag+'_perm').prop('checked', true);
            }else{
                $('.'+data_flag+'_perm').prop('checked', false);
            }
        });
    }
    
    //Checked Or Unchecked all schemes modules
    if($('.checked_unchecked_sm').length > 0){
        $('.checked_unchecked_sm').on('click', function(){
            //Module Schemes
            var module_scheme = $(this).attr('data-scheme');
            
            //Total Modules
            var modules_length = $('.'+module_scheme+'_mo_perm').length;
            
            //Modules Checked Count
            var modules_count = 0;
            $('.'+module_scheme+'_mo_perm').each(function(){
                if($(this).prop('checked') == true){
                    modules_count++;
                }
            });
            
            //Checked All
            if(modules_length == modules_count){
                $('#'+module_scheme+'checkall').prop('checked', true);
            }else{
                $('#'+module_scheme+'checkall').prop('checked', false);
            }
        });
    }
});

function schemewisetype(recid) {
    var id = recid;
    var schemes = document.getElementById("schemes_" + id).checked;

    if (schemes == true) {
        if (id == '1') {
            $("#step1").show();
            $("#schemes_" + id).attr('checked', true);
        } else if (id == '2') {
            $("#research1").show();
            $("#schemes_" + id).attr('checked', true);
        } else if (id == '3') {
            $("#swadhar1").show();
            $("#schemes_" + id).attr('checked', true);
        } else if (id == '4') {
            $("#ujjawala1").show();
            $("#schemes_" + id).attr('checked', true);
        } else if (id == '5') {
            $("#creche1").show();
            $("#schemes_" + id).attr('checked', true);
        } else if (id == '6') {
            $("#icds1").show();
            $("#schemes_" + id).attr('checked', true);
        }
    } else {
        if (id == '1') {
            $("#step1").hide();
            $('#step input').prop('checked', false);
            $("#schemes_" + id).removeAttr('checked');
            $(".step_moduleprms1").removeAttr('checked');
            $('#stepcheckall').prop('checked', false);
        } else if (id == '2') {
            $("#research1").hide();
            $('#research input').prop('checked', false);
            $("#schemes_" + id).removeAttr('checked');
            $(".resrch_moduleprms1").removeAttr('checked');
            $('#resrchcheckall').prop('checked', false);
        } else if (id == '3') {
            $("#swadhar1").hide();
            $('#swadhar input').prop('checked', false);
            $("#schemes_" + id).removeAttr('checked');
            $(".swdhr_moduleprms1").removeAttr('checked');
            $('#swdhrcheckall').prop('checked', false);
        } else if (id == '4') {
            $("#ujjawala1").hide();
            $('#ujjawala input').prop('checked', false);
            $("#schemes_" + id).removeAttr('checked');
            $(".ujwla_moduleprms1").removeAttr('checked');
            $('#ujjwlacheckall').prop('checked', false);
        } else if (id == '5') {
            $("#creche1").hide();
            $('#creche input').prop('checked', false);
            $("#schemes_" + id).removeAttr('checked');
            $(".creche_moduleprms1").removeAttr('checked');
            $('#crechecheckall').prop('checked', false);
        } else if (id == '6') {
            $("#icds1").hide();
            $('#icds1 input').prop('checked', false);
            $("#schemes_" + id).removeAttr('checked');
            $(".icds_moduleprms1").removeAttr('checked');
            $('#icdscheckall').prop('checked', false);
        }
    }
}
/***Functions Start for Select All Functionality***/
function schemescheckall() {

    var role = $('#role').val();
    role = $.trim(role);

    var checked = false;
    var aa = document.getElementsByClassName('scheme_details');
    if (document.getElementById("schemecheckall").checked == true) {
        checked = true
        $("#step1").show();
        if (role == 3)
        {
            $("#research1").hide();
        } else
        {
            $("#research1").show();
        }
        $("#swadhar1").show();
        $("#ujjawala1").show();
        $("#creche1").show();
        $("#icds").show();
    } else {
        checked = false
        $("#step1").hide();
        $('#step input').prop('checked', false);
        $(".step_moduleprms1").removeAttr('checked');
        $('#stepcheckall').prop('checked', false);

        $("#research1").hide();
        $('#research input').prop('checked', false);
        $(".resrch_moduleprms1").removeAttr('checked');
        $('#resrchcheckall').prop('checked', false);

        $("#swadhar1").hide();
        $('#swadhar input').prop('checked', false);
        $(".swdhr_moduleprms1").removeAttr('checked');
        $('#swdhrcheckall').prop('checked', false);

        $("#ujjawala1").hide();
        $('#ujjawala input').prop('checked', false);
        $(".ujwla_moduleprms1").removeAttr('checked');
        $('#ujjwlacheckall').prop('checked', false);

        $("#creche1").hide();
        $('#creche input').prop('checked', false);
        $(".creche_moduleprms1").removeAttr('checked');
        $('#crechecheckall').prop('checked', false);

        $("#icds").hide();
        $('#icds input').prop('checked', false);
        $(".icds_moduleprms1").removeAttr('checked');
        $('#icdscheckall').prop('checked', false);
    }
    for (var i = 0; i < aa.length; i++) {
        aa[i].checked = checked;
    }
}

/***Functions Start for Select All Functionality***/

function checkedAll() {

    var checked = false;
    var aa = document.getElementsByClassName('step_moduleprms1');
    if (document.getElementById("stepcheckall").checked == true)
    {
        checked = true
    } else
    {
        checked = false
    }
    for (var i = 0; i < aa.length; i++) {
        aa[i].checked = checked;
    }
}


function checkresrall() {

    var checked = false;
    var aa = document.getElementsByClassName('resrch_moduleprms1');
    if (document.getElementById("resrchcheckall").checked == true)
    {
        checked = true
    } else
    {
        checked = false
    }
    for (var i = 0; i < aa.length; i++) {
        aa[i].checked = checked;
    }
}

function checkswdhrall() {

    var checked = false;
    var aa = document.getElementsByClassName('swdhr_moduleprms1');
    if (document.getElementById("swdhrcheckall").checked == true)
    {
        checked = true
    } else
    {
        checked = false
    }
    for (var i = 0; i < aa.length; i++) {
        aa[i].checked = checked;
    }
}

function checkujjwlaall() {

    var checked = false;
    var aa = document.getElementsByClassName('ujwla_moduleprms1');
    if (document.getElementById("ujjwlacheckall").checked == true)
    {
        checked = true
    } else
    {
        checked = false
    }
    for (var i = 0; i < aa.length; i++) {
        aa[i].checked = checked;
    }
}

function checkcrecheall() {

    var checked = false;
    var aa = document.getElementsByClassName('creche_moduleprms1');
    if (document.getElementById("crechecheckall").checked == true)
    {
        checked = true
    } else
    {
        checked = false
    }
    for (var i = 0; i < aa.length; i++) {
        aa[i].checked = checked;
    }
}

/****** Function for budget work ****/
function getHeadAccNo(id)
{
    $.ajax({
        type: "POST",
        url: baseURL + 'users/getHeadofAccNo',
        data: 'schemeid=' + id + '&' + token_name + '=' + csrf_token,
        dataType: 'json',
        success: function (jsondata) {
            if (jsondata.status == true)
            {
                var accno = "";
                accno += "<option value=''>Select Head Of A/C</option>";
                for (var i = 0; i < jsondata.data.length; i++)
                {
                    accno += "<option value='" + jsondata.data[i].PAO + "'>" + jsondata.data[i].PAO + "</option>";
                }
                $("#accno").html(accno);
                $("#accno").removeAttr("disabled");
            } else {
                var accno = "";
                accno += "<option value=''>Select Head Of A/C</option>";
                $("#accno").html(accno);
                $("#accno").attr("disabled", true);
                $("#budgetamountinfo").hide();
            }
        }
    });
}


$(document).ready(function () {
    $("#budgetamountinfo").hide();


    $('#amntbook').keydown(function (e) {
        if (e.shiftKey || e.ctrlKey || e.altKey) {
            e.preventDefault();
        } else {
            var key = e.keyCode;
            if (!((key == 8) || (key == 46) || (key >= 35 && key <= 40) || (key >= 48 && key <= 57) || (key >= 96 && key <= 105))) {
                e.preventDefault();
            }
        }
    });

    $('.step_moduleprms, .resrch_moduleprms,.swdhr_moduleprms,.ujwla_moduleprms,.creche_moduleprms').on('click', function () {
        if (this.checked) {
            $(this).attr('checked', true);

        } else {
            $(this).removeAttr('checked');

        }
    });

    $('.step_moduleprms1, .resrch_moduleprms1,.swdhr_moduleprms1,.ujwla_moduleprms1,.creche_moduleprms1,#stepcheckall').on('click', function () {
        if (this.checked) {
            $(this).attr('checked', true);
        } else {
            $(this).removeAttr('checked');
        }
    });
});

function getBudgetdata(id) {
    var acc = id;
    var schemeid = $("#schemelist").val();
    $.ajax({
        type: "POST",
        url: baseURL + 'users/getBudgetdatainfo',
        data: 'acc=' + acc + '&schemeid=' + schemeid + '&' + token_name + '=' + csrf_token,
        dataType: "json ",
        success: function (jsondata) {
            if (jsondata.status == true)
            {
                $("#budgetamountinfo").show();

                for (var i = 0; i < jsondata.data.length; i++)
                {
                    $("#be_plan").val(jsondata.data[i].BE_Plan);
                    $("#be_nonplan").val(jsondata.data[i].BE_NonPlan);
                    $("#be_ne").val(jsondata.data[i].BE_NE);
                    $("#re_plan").val(jsondata.data[i].RE_Plan);
                    $("#re_nonplan").val(jsondata.data[i].RE_NonPlan);
                    $("#re_ne").val(jsondata.data[i].RE_Ne);
                    $("#fg_plan").val(jsondata.data[i].FG_Plan);
                    $("#fg_nonplan").val(jsondata.data[i].FG_NonPlan);
                    $("#fg_ne").val(jsondata.data[i].FG_Ne);
                    $("#expndtr_plan").val(jsondata.data[i].Exp_Plan);
                    $("#expndtr_nonplan").val(jsondata.data[i].Exp_NonPlan);
                    $("#expndtr_ne").val(jsondata.data[i].Exp_NE);

                    var balncplan_be = (jsondata.data[i].BE_Plan - jsondata.data[i].Exp_Plan);
                    var balncnonplan_be = (jsondata.data[i].BE_NonPlan - jsondata.data[i].Exp_NonPlan);
                    var balncne_be = (jsondata.data[i].BE_NE - jsondata.data[i].Exp_NE);

                    $("#balnc_plan").val(balncplan_be);
                    $("#balnc_nonplan").val(balncnonplan_be);
                    $("#balnc_ne").val(balncne_be);
                }

                var sanctionno = "";
                sanctionno += "<option value=''>Select Sanction Order No.</option>";
                for (var i = 0; i < jsondata.sanctiondata.length; i++)
                {
                    sanctionno += "<option value='" + jsondata.sanctiondata[i].sanctionno + "'>" + jsondata.sanctiondata[i].sanctionno + "</option>";
                }
                $("#sanctionorderno").html(sanctionno);
            }
        }
    });
}

function getfileno(id)
{
    var schemeid = $("#schemelist").val();
    $.ajax({
        type: "POST",
        url: baseURL + 'users/getsanctionwisefileno',
        data: 'sanctionno=' + id + '&schemeid=' + schemeid + '&' + token_name + '=' + csrf_token,
        dataType: 'json',
        success: function (jsondata) {
            if (jsondata.status == true)
            {
                var eofficeno = "";
                eofficeno += "<option value=''>File No.</option>";
                for (var i = 0; i < jsondata.data.length; i++)
                {
                    eofficeno += "<option value='" + jsondata.data[i].eofficeno + "'>" + jsondata.data[i].eofficeno + "</option>";
                }
                $("#eofficeno").html(eofficeno);
                $("#eofficeno").removeAttr("disabled");
            } else {
                var eofficeno = "";
                eofficeno += "<option value=''>File No.</option>";
                $("#eofficeno").html(eofficeno);
                $("#eofficeno").attr("disabled", true);
            }
        }
    });
}

function getbudgetamount(bookamnt)
{
    var schemeid = $("#schemelist").val();
    var accno = $("#accno").val();
    var budgetplan = $("#budgetplan").val();
    $.ajax({
        type: "POST",
        url: baseURL + 'users/getbeammount',
        data: 'schemeid=' + schemeid + '&accno=' + accno + '&budgetplan=' + budgetplan + '&' + token_name + '=' + csrf_token,
        dataType: 'json',
        success: function (jsondata) {
            if (jsondata.status == true)
            {
                var amountbe = jsondata.data[0].amountbe;
                amountbe = parseInt(amountbe);

                //Book Amount
                bookamnt = parseInt(bookamnt);

                if (bookamnt > amountbe)
                {
                    alert("Amount you have enter is not availabe in an Acc");
                    $("#amntbook").val('');
                    $("#amntbook").focus();
                    return false;
                }
            }
        }
    });
}
/**Function End here for budget work ****/

/****common Function Start For Pattern check For Email ****/

function validateEmailid(uesremail)
{
    var email = uesremail;
    email = $.trim(email);
    //var pattern = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    var pattern = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/;
    if (pattern.test(email))
    {
        return true;
    } else
    {
        alert('Please Enter valid email');
        return false;
    }
}

/****Function End For Research University Approval ****/

function storeid(id,univdtl) {
    var ids = id.value;
    $("#userapproved_id").val(ids);
    $("#showunivdetail").html(univdtl);
}

function submitapprovedata(recid) {
    var approvreason = $("#approvreason").val();
    var counter = 0;
    if (approvreason != '') {
        var formDetails = $('#approved_reason');
        $.ajax({
            type: "POST",
            url: baseURL + 'goi/approvereasons',
            data: formDetails.serialize(),
            dataType: "json ",
            success: function (data) {
                if (data.status == true) {
                    swal({
                        title: "Approve Remark Submitted",
                        text: data.message,
                        type: "success",
                        confirmButtonText: "OK",
                    },
                    function () {
                        location.reload();
                    });
                } else {
                    $("showuniverr").html(data.message);
                }
            },
            sending: function (file, xhr, formData) {
                formData.append(token_name, csrf_token);
            },
        });
    }
    else
    {
        if(approvreason == ''){
            $("#approvreasonblank").text("Approve Reason Should not be blank");
            $("#approvreason").focus();
            $("#approvreasonblank").show();
        }
        return false;
    }
    $("#approv_schemepremssion").css('display', 'none');
    $("#approvreasonblank").css('display', 'none');
}

/****Function End For Approval ****/
function store_id(id,univdetail) {
    var ids = id.value;
    $("#userrejectd_id").val(ids);
    $("#showunivrejectdetail").html(univdetail);
}
function arappmodule(id,appdetail) {
    var ids = id.value;
    $("#arapp_id").val(ids);
    $("#showarappdetail").html(appdetail);
}

function submitrejectdata(recid) {
    $("#rejectasonblank").text('');
    var rejectreason = $("#rejectreasons").val();
    if (rejectreason != '') {
        var formDetails = $('#rejection_reason');
        $.ajax({
            type: "POST",
            url: baseURL + 'goi/rejectionreasons',
            data: formDetails.serialize(),
            dataType: "json ",
            success: function (data) {
                if (data.status == true) {
                    swal({
                        title: "Rejection Remark Submitted",
                        text: data.message,
                        type: "success",
                        confirmButtonText: "OK",
                    },
                    function () {
                        location.reload();
                    });
                }
            },
            sending: function (file, xhr, formData) {
                formData.append(token_name, csrf_token);
            },
        });
        $("#rejectasonblank").css('display', 'none');
    }else{
        $("#rejectasonblank").text("Reject Reason Should not be blank");
        $("#rejectreasons").focus();
        $("#approvreasonblank").show();
    }
}

/* password strength js   */
$(function () {
        $("#newpassword").bind("keyup", function () {
            //TextBox left blank.
            if ($(this).val().length == 0) {
                $("#password_strength").html("");
                 $("#pass_strength").hide();
                return;
            }
 
            //Regular Expressions.
            var regex = new Array();
            regex.push("[A-Z]"); //Uppercase Alphabet.
            regex.push("[a-z]"); //Lowercase Alphabet.
            regex.push("[0-9]"); //Digit.
            regex.push("[$@$!%*#?&]"); //Special Character.
 
            var passed = 0;
 
            //Validate for each Regular Expression.
            for (var i = 0; i < regex.length; i++) {
                if (new RegExp(regex[i]).test($(this).val())) {
                    passed++;
                }
            }
 
 
            //Validate for length of Password.
            if (passed > 2 && $(this).val().length > 8) {
                passed++;
            }
 
            //Display status.
            var color = "";
            var strength = "";
             var value = "";
            switch (passed) {
                case 0:
                case 1:
                    strength = "Weak";
                    color = "red";
                    value= "15";
                    break;
                case 2:
                   strength = "Weak";
                    color = "red";
                    value= "15";
                    break;
                case 3:
                case 4:
                    strength = "Weak";
                    color = "red";
                    value= "15";
                    break;
                case 5:
                    strength = "Strong";
                    color = "darkgreen";
                     value= "85";
                    break;
            }
            $("#pass_strength").show();
            $("#password_strength").html(strength);
            $("#password_strength").css("color", color);
            $("#password_strength").css("font-weight", 'bold');
            $("#pass_strength").val(value);
        });
        });

/****Function End****/
/*****FUNCTION FOR CHECK EMAIL ID IF USER IS GOVT USER
 *****2 = GOI USER
 *****3 = STATE USER      
 ********/
function checkemailonuserrole(emailid){
   var userlevel = $('input[name=userlevel]:checked').val();
   userlevel = $.trim(userlevel);
   if(userlevel==''){
       $("#stateUesremail").val('');
       $("#stateUesremail").next().html('Please select user level first');
       return false;
   } else if(userlevel=='2' || userlevel=='3' || userlevel=='9'){
       if(emailid.includes('nic.in') !=false || emailid.includes('gov.in') != false){
        $("#stateUesremail").next().html('');
        return true;
       } else{
           $("#stateUesremail").val('');
           $("#stateUesremail").next().html('Email Id should be nic.in or gov.in');
           return false;
       }
       
   }
}

/********FUNCTION FOR CHECK SCHEME
 ******** 2 = CHECK MULTIPLE SCHEME
 ******** ELSE = CHECK ONLY ONE SCHEME
 * ************/
$(function(){
    $(".schemechecked").change(function(){
        var userlevel = $('input[name=userlevel]:checked').val();
        userlevel = $.trim(userlevel);
        if(userlevel==''){
            $("#schemeerr").html('Please select user level first');
            $('.schemechecked').removeAttr('checked');
        } else if(userlevel!=='2'){
            $('.schemechecked').not(this).removeAttr('checked');
            $("#schemeerr").html('');
        } else{ 
            $("#schemeerr").html('');
        }
    });
    
    //Scheme Permission Module
    $("#research_module").click(function () {
        if ($(this).is(":checked")) {
            $("#resrchcheckall").removeAttr("disabled");
            $(".research_module_list").removeAttr("disabled");
        } else {
            $("#resrchcheckall").attr("disabled", true);
            $(".research_module_list").attr("disabled", true);
        }
    });

    $("#swadhar_module").click(function () {
        if ($(this).is(":checked")) {
            $("#swdhrcheckall").removeAttr("disabled");
            $(".swadhar_module_list").removeAttr("disabled");

        } else {
            $("#swdhrcheckall").attr("disabled", true);
            $(".swadhar_module_list").attr("disabled", true);
        }
    });

    $("#ujjawala_module").click(function () {
        if ($(this).is(":checked")) {
            $("#ujjwlacheckall").removeAttr("disabled");
            $(".ujjawala_module_list").removeAttr("disabled");
        } else {
            $("#ujjwlacheckall").attr("disabled", true);
            $(".ujjawala_module_list").attr("disabled", true);
        }
    });

    $("#creche_module").click(function () {
        if ($(this).is(":checked")) {
            $("#crechecheckall").removeAttr("disabled");
            $('.creche_module_list').removeAttr("disabled");
        } else {
            $("#crechecheckall").attr("disabled", true);
            $(".creche_module_list").attr("disabled", true);
        }
    });    
});

/*{@}Added method for get action taken by id and role || Created on: 31-08-2018 || Updated on : 04/09/2018**/
function approveDistrictUser(id, exist_user) {
    var ids = id.value;
    $("#userapprovedid").val(ids);
    if (exist_user > 0) {
        $('#approve_modal').modal('hide');
        $('#alert-div').show();
        $('#alert-msg').html('User already approved and active for this District');
    } else {
        $('#alert-div').hide();
        $('#approve_modal').modal('show');
    }
}

function rejectDistrictUser(id) {
    var ids = id.value;
    $("#userrejectdid").val(ids);
}

/****Function Start For District User Approval Reason ****/
function saveApprovedDetails() {
    var apprvreason = $("#apprvreason").val();
    if (apprvreason != '') {
        $("#approve_reason_warning").empty();
        var formDetails = $('#approved_reason');
            $.ajax({
                type: "POST",
                url: baseURL + 'users/districtUserApprovedReason',
                data: formDetails.serialize(),
                dataType: "json",
                success: function (data) {
                    if (data.status == true) {
                        swal({
                            title: "Approve Remark Submitted",
                            text: data.message,
                            type: "success",
                            confirmButtonText: "OK",
                        },
                                function () {
                                    location.href = location.href;
                                });
                    }else{
                        window.location.href = data.redirect_url;
                    }
                },
                sending: function (file, xhr, formData) {
                    formData.append(token_name, csrf_token);
                },
            });
    }else {
        $("#approve_reason_warning").text("Approve Reason Should not be blank");
        $("#apprvreason").focus();
        $("#approve_reason_warning").show();
    }
}

/****Function Get Reject District User Reason And Save Reject Reason Details ****/
function saveRejectDetails(){
    var rejectreason = $("#rejectreason").val();
    if (rejectreason != '') {
        $("#reject_reason_warning").empty();
        var formDetails = $('#rejection_reason');
        $.ajax({
            type: "POST",
            url: baseURL + 'users/rejectionreason',
            data: formDetails.serialize(),
            dataType: "json ",
            success: function (data) {
                if (data.status == true) {
                    swal({
                        title: "Rejection Remark Submitted",
                        text: data.message,
                        type: "success",
                        confirmButtonText: "OK",
                    },
                            function () {
                                location.href = location.href;
                            });
                }

            },
            sending: function (file, xhr, formData) {
                formData.append(token_name, csrf_token);
            },
        });
        
    } else {
        $("#reject_reason_warning").text("Reject Reason Should not be blank");
        $("#rejectreason").focus();
        $("#reject_reason_warning").show();
    }

}
/*hide scheme select when user type is GOI
$(function(){
    $('#user_type').on('change', function(){
       var usertype = $(this).find(':selected').data('id');
       if(usertype=='2'){
           $('#schemeoption').attr('disabled','true');
       } else{
           $('#schemeoption').removeAttr('disabled');
       }
    });
});*/

/**************editActiveUser OR approveRegisteredUser ******************/
function editActiveUser(){
    var checked_schemes = new Array();
    var error_count = 0;
    $('.scheme_details').each(function(){
        if($(this).prop('checked') == true){
            var data_module = $(this).attr('data-module');
            data_module = $.trim(data_module);
            data_module = data_module.split('_');
            data_module = data_module[0];
            checked_schemes.push(data_module);
        }
    });
    /*if(checked_schemes.length == 0){
        alert('Please select at least one scheme for permission access.');
        error_count++;
    }else{
        for(var i=0; i<checked_schemes.length; i++){
            var scheme_name = checked_schemes[i];
            scheme_name = $.trim(scheme_name);
            var class_obj = '.'+scheme_name+'_mo_perm';
            var module_checked = $(class_obj+':checkbox:checked').length;
            if(module_checked == 0){
                alert('Please select atleast one module of '+scheme_name+' scheme!');
                error_count++;
            }
        }
    }*/
    
    if(checked_schemes.length > 0){
        for(var i=0; i<checked_schemes.length; i++){
            var scheme_name = checked_schemes[i];
            scheme_name = $.trim(scheme_name);
            var class_obj = '.'+scheme_name+'_mo_perm';
            var module_checked = $(class_obj+':checkbox:checked').length;
            if(module_checked == 0){
                alert('Please select atleast one module of '+scheme_name+' scheme!');
                error_count++;
            }
        }
    }
    
    if(error_count == 0){
        $.ajax({
            type: "POST",
            url: baseURL + 'admin/addEditPermission',
            data: $('#edit_user').serialize(),
            dataType: 'JSON',
            success: function (data) {
                if(data.status == true){
                    swal({
                        title: "User Details Successfully Submitted",
                        text: data.message,
                        type: "success",
                        confirmButtonText: "OK",
                    },
                    function () {
                        if(data.user_type == 'N'){
                            location.href = baseURL;
                        }else{
                            location.reload();
                        }
                    });
                }
                else
                {
                    $('#msg').html(data.messages);
                }
            },
            sending: function (file, xhr, formData) {
                formData.append(token_name, csrf_token);
            }
        });
    }else{
        return false;
    }
}

/** UpperCase of first character of string **/
function uc_first_character(str){
    str = str.toLowerCase().replace(/\b[a-z]/g, function(letter){
        return letter.toUpperCase();
    });
    return str;
}

/*Sort Order Module Function*/

function sortOrderModule(){

        jQuery("#module_list").jqGrid({
            url: baseURL+'admin/getModuleList',
            postData: {
                scheme_id: function() { return jQuery("#scheme_id").val(); },
                som: function() { return jQuery("#som").val(); },
                'csrf_test_name': csrf_token
            },
            mtype : "post",              
            datatype: "json",            
            colNames:['Position', 'Scheme Id', 'Module ID', 'Module Name'],       //Grid column headings
            colModel:[
            {name:'sort_order',index:'sort_order', width:180, align:"center", editable: true,  editrules: { required:false}, search:false, resizable: false, fixed: true},
            {name:'scheme_id',index:'scheme_id', width:10, align:"left", hidden: true , editable: true},
            {name:'module_id',index:'module_id', width:10, align:"left", hidden: true , editable: true},
            {name:'module_name',index:'module_name', width:350, align:"left",editable:true, editoptions: { disabled: "disabled" },
            resizable: false, fixed: true}
            ],
            jsonReader: { id: "module_id" },
            rownumbers: false,
            rowNum:10,
            //width: 350,
            // height: "100%",
            autowidth: false,
            rowList:[10,20,30,40,50],
            pager: jQuery('#pager'),
            sortname: 'sort_order',
            viewrecords: true,            
            gridview: true,  

            ondblClickRow: function(id){    

                $("#module_list").editGridRow(id, {closeAfterEdit:true, mtype:'POST'});                
            },

            sortorder: "asc",       
            editurl: baseURL+'admin/crudModule', //URL Process CRUD
            multiselect: false,
            caption:"Schemes Module List"
        }).navGrid('#pager',
        {view:true,edit:true,add:false,del:false},
        {closeOnEscape:true},
        {closeOnEscape:true},
        {closeOnEscape:true},
        {closeOnEscape:true},
        {
            closeOnEscape:true,closeAfterSearch:false,multipleSearch:false, 
            multipleGroup:false, showQuery:false,
            drag:true,showOnLoad:false,sopt:['cn'],resize:false,
            caption:'Search Record', Find:'Search', 
            Reset:'Reset Search'
        }
        ); 

        jQuery("#module_list").jqGrid('setGridParam',{datatype:'json'}).trigger('reloadGrid');
}

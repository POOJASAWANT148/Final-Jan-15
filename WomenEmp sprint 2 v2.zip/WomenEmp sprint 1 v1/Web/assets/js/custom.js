var gloabalType = '';
var appNum = '';
var schemeIds = '';
var parts='';
var docids = '';
var divid = '';
var additionalDocumentName='';
var docFlag = '';
var appFile = "application/pdf";
if(getParameterByName('a') == 5){
    appFile = "application/pdf, image/jpeg";
}
//var commonSalt='98765~!$%^&*()43210.socialcause@_625A#CS';
var commonSalt='ngomwcd@gov.in_625A#CS';
function updateGlobal(id)
{
    gloabalType = id;
    
    var parts = id.split('-', 2);
    divid = parts[0];
    docids = parts[1];
}

function updateGlobal1(id, appNo, schemeId)
{
    gloabalType = id;
    appNum = appNo;
    schemeIds = schemeId;

    var parts = id.split('-', 2);
    divid = parts[0];
    docids = parts[1];
}

function getUploadAdditionalDocuments(xhr, obj='')
{
    if(obj != '' && obj == 'pdf_img'){
        docFlag = obj;
    }
    
    gloabalType = xhr;
    var parts = xhr.split('-', 2);
    divid = parts[0];
    docids= parts[1];
    
    additionalDocumentName='';
    
    if($('#document_'+docids).length > 0){
        
        var documentValue = $('#document_'+docids).val();
        documentValue = $.trim(documentValue);
        additionalDocumentName = documentValue;
        
        if(documentValue == ''){
            alert('Additional document required!');
            $('#document_'+docids).focus();
            return false;
        }
    }
}

//  Dropzone code for All scheme-------------------------
if (Controller != "home")
{
    Dropzone.autoDiscover = false;
    Dropzone.options.commonfiledropzone = {
        success: function (file, response) {
            this.removeFile(file);
            var jsresp = JSON.parse(response);
            var url = window.location.href;
            var n = url.lastIndexOf("index.html");
            var pathtoredirect = url.substring(n);
            if (jsresp.status == true) {
                swal({
                    title: "Thank You!",
                    text: "Document Submitted Successfully!",
                    type: "success",
                    confirmButtonText: "OK",
                },
                function () {
                    $('#commonfileupload').modal('hide');
                    //$('.modal-backdrop').hide();
                    //$('body').removeClass("modal-open");
                    $('#' + divid).show();
                    $('#' + divid).attr("href", jsresp.file_path);
                });
            }else if (jsresp.status == false){
                swal("Error!", "Please upload only pdf file and Filesize should be less than or equal to 5 mb", "error");
            }else{
                swal("Error!", "Error In Uploading Try After Some Time.", "error");
            }
        },
        sending: function (file, xhr, formData) {
            formData.append("doc_id", docids);
            formData.append(token_name, csrf_token);
            if (getParameterByName("aid"))
            {
                formData.append("scheme_id", getParameterByName("a"));
                formData.append("aid", getParameterByName("aid"));
            }
            else
            {
                formData.append("scheme_id", schemeIds);
                formData.append("aid", appNum);
            }
        },
        dictDefaultMessage: "Click / Drop here to upload files",
        addRemoveLinks: true,
        dictRemoveFile: "Remove",
        maxFiles: 1,
        maxFilesize: 5,
        acceptedFiles: 'application/pdf',
        parallelUploads: 1
    }
    $(function () {
        /* Upload Profile Pic */
        $('#commonfiledropzone').dropzone({url: baseURL + "ngo/upload_Allschemefiles", uploadMultiple: true, dictDefaultMessage: "Click / Drop here to upload files"});
    });
}


//  Dropzone code for All BlackList NGO  Document Upload-------------------------
if(Controller != "home")
{	  

	Dropzone.autoDiscover = false;
	Dropzone.options.commonngoblacklist = {
			  
	    success: function(file, response){
                        this.removeFile(file);
			var jsresp = JSON.parse(response);
			var url = window.location.href; 
			var n = url.lastIndexOf("index.html");
			var pathtoredirect= url.substring(n);
			
	        if(jsresp.status == true){
				swal({
				  title: "Thank You!",
				  text: "Document Submitted Successfully!",
				  type: "success",
				  confirmButtonText: "OK",
				  },
				function(){
				
				   $('#ngoblacklistdocuments').modal('hide');
                                  //$('.modal-backdrop').hide();
                                  //$('body').removeClass("modal-open");
                                 $('#' +divid).show();
                             

                                $('#blockListDocument').attr("href", jsresp.file_path).html('<i class="fa fa-file-pdf-o fa-2x text-red"></i> Click to view PDF');
    		      
				});
			}
			else if(jsresp.status == false)
			{
			
					swal("Error!","Please upload only pdf file and Filesize should be less than or equal to 5 mb","error");
			}
			else{

					swal("Error!","Error In Uploading Try After Some Time.","error");
			}
	    },

                sending:function(file, xhr, formData){
            //formData.append("doc_id", docids);
           formData.append(token_name, csrf_token);
            
                },
	    
	    dictDefaultMessage:"Click / Drop here to upload files",
	    addRemoveLinks: true,
	    dictRemoveFile:"Remove",
	    maxFiles:1,
	    maxFilesize:2,
            acceptedFiles: 'application/pdf',
	    parallelUploads:1
	}	
	
	$(function() {
	  /* Upload Profile Pic */
		$('#commonngoblacklist').dropzone({ url: baseURL + "ngo/upload_BlackListDocument",uploadMultiple:true,dictDefaultMessage:"Click / Drop here to upload files"});	
	});
}




if(Controller != "home")
{	
	Dropzone.autoDiscover = false;
	Dropzone.options.userProfilePic = {	  
	    success: function(file, response){
			var jsresp = JSON.parse(response);
			var url      = window.location.href; 
			var n = url.lastIndexOf("index.html");
			var pathtoredirect= url.substring(n);
			
	        if(jsresp.status == true){
				swal({
				  title: "Thank You!",
				  text: "Profile Image Updated Successfully!",
				  type: "success",
				  confirmButtonText: "OK",
				  },
				function(){
				 //location.href = baseURL + "users"+pathtoredirect;
                                 location.reload(true);
				});
			}
			else if(jsresp.status == false)
			{
				swal("Error!","Please select only JPEG file and Filesize should be less than or equal to 1 mb .","error");
			}
                        
	    },
            sending:function(file, xhr, formData){
            formData.append(token_name, csrf_token);  
            },
	    // params: { },
	    dictDefaultMessage:"Click / Drop here to upload files",
	    addRemoveLinks: true,
	    dictRemoveFile:"Remove",
            acceptedFiles: 'image/jpeg',
	    maxFiles:1,
	    maxFilesize:1,
	    parallelUploads:1
            
	}
         
	
	$(function() {
	  /* Upload Profile Pic */
		$('#userProfilePic').dropzone({ url: baseURL + "users/updateProfilePic",uploadMultiple:true,dictDefaultMessage:"Click / Drop here to upload files"});	
	});
}
if(Controller != "home")
{	
	Dropzone.autoDiscover = false;
	Dropzone.options.stateUploaded = {	  
	    success: function(file, response){
			var jsresp = JSON.parse(response);
			var url      = window.location.href; 
			var n = url.lastIndexOf("index.html");
			var pathtoredirect= url.substring(n);
			
	        if(jsresp.status == true){
				swal({
				  title: "Success",
				   text: "Document Uploaded Successfully!",
				  type: "success",
				  confirmButtonText: "OK",
				  },
				function(){
				  //location.href = baseURL + "ngo"+pathtoredirect;
                                  $('#stateUploadeddocs').hide();
                                  $('.modal-backdrop').hide();
                                  $('body').removeClass("modal-open");                                 
                                  var htmlanchor = '<a style="float:right;"target="_blank" id="legal_entity_link" href="'+jsresp.file_path+'"><i class="fa fa-file-pdf-o fa-2x text-red"></i> Click to view PDF</a>';
                                  $(htmlanchor).insertAfter("#stateUploadeddoc");
                             	});
			}
			else if(jsresp.status == false)
			{
				swal("Error!","Error In Uploading Try After Some Time.","error");
			}
	    },
	      params: {'aid':getParameterByName("aid")},
	    dictDefaultMessage:"Click / Drop here to upload files",
	    addRemoveLinks: true,
	    dictRemoveFile:"Remove",
	    maxFiles:1,
            acceptedFiles: ".pdf",
	    maxFilesize:5,
	    parallelUploads:1
	}	
	
	$(function() {
	  /* Upload Profile Pic */
		$('#stateUploaded').dropzone({ url: baseURL + "state/stateDocupload",uploadMultiple:true,dictDefaultMessage:"Click / Drop here to upload files"});	
	});
}

// Upload Additional five files
if(Controller != "home")
{
    Dropzone.autoDiscover = false;
    Dropzone.options.commonadditionalfiles = {
        
        //Response Success
        success: function(file, response){
            
            this.removeFile(file);
            var jsonResponse = JSON.parse(response);
            var url = window.location.href; 
            var lastIndex = url.lastIndexOf("index.html");
            
            if(jsonResponse.status == true){
                swal({
                    title: "Thank You!",
                    text: "Additional Document Submitted Successfully!",
                    type: "success",
                    confirmButtonText: "OK",
                },
                function(){
                    $('#additionaldocuments').modal('hide');
                    $('.modal-backdrop').hide();
                    $('body').removeClass("modal-open");
                    $('#'+divid).show();
                    $('#'+divid).attr("href", jsonResponse.file_path);
                    
                    if(jsonResponse.extn == 'jpg' || jsonResponse.extn == 'jpeg'){
                        $('#'+divid).html('<i class="fa fa-file-image-o fa-2x text-red"></i>&nbsp;Download');
                    }else{
                        $('#'+divid).html('<i class="fa fa-file-pdf-o fa-2x text-red"></i>&nbsp;Download');
                    }
                });
            }
            else if(jsonResponse.status == false)
            {
                swal("Error!","Please upload only pdf file and Filesize should be less than or equal to 5 mb","error");
            }
            else if(jsonResponse.status == 'error')
            {
                swal("Error!",jsonResponse.message,"error");
            }
            else
            {
                swal("Error!","Error In Uploading Try After Some Time.","error");
            }
        },
        sending:function(file, xhr, formData){
            formData.append("doc_id", docids);
            formData.append(token_name, csrf_token);
            formData.append("doc_name", additionalDocumentName);
            
            if(getParameterByName("aid")){
                formData.append("scheme_id", getParameterByName("a"));
                formData.append("aid", getParameterByName("aid"));
            }
            
            if(docFlag != '' && docFlag == 'pdf_img'){
                formData.append("docFlag", docFlag);
            }
        },
        dictDefaultMessage:"Click / Drop here to upload files",
        addRemoveLinks: true,
        dictRemoveFile:"Remove",
        maxFiles:1,
        acceptedFiles: appFile,
        maxFilesize:5,
        parallelUploads:1
    }
    $(function() {
        //Upload Additional Files
        $('#commonadditionalfiles').dropzone({url: baseURL + "ngo/getUploadAdditionalFiles",uploadMultiple:true,dictDefaultMessage:"Click / Drop here to upload files"});
    });
}

$(document).ready(function(){
	
	var text = getParameterByName("text");
        text = $.trim(text);
	var message = getParameterByName("message");
        message = $.trim(message);
        if(text == 'xyz'){
            text = 'I Am Sorry!';
            message = 'Password should contain at least one lowercase letter, one uppercase letter, one numeric digit, and one special character (@#$%) and length should be beween 6 to 15.';
        }
	var at = getParameterByName("at");
	if(text != null && text != 'undefined' && text != "")
	{
            swal(text,message,at);
            swal({
                title: text,
                text: message,
                type: at,
                showCancelButton: false,
                confirmButtonColor: "#DD6B55",
                confirmButtonText: "OK",
                closeOnConfirm: false
            }, function(){
              location.href = baseURL+'home';
            });
	}
});
/* Common Function */
function getParameterByName(name) {
    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
        results = regex.exec(location.search);
    return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}



$(document).ready(function(){
 var sz = $( "#carousel-example-generic .carousel-inner .item" ).size();
if(sz=="1"){
  jQuery("#carousel-example-generic .carousel-inner .item:first-child").addClass("active");
  jQuery("#carousel-example-generic .carousel-control").hide();
}
else{
  jQuery("#carousel-example-generic .carousel-inner .item:first-child").addClass("active");  
} 
});
 

function uploadOnEoffice(id)
{
	if(id != "")
   {
   	 var idArray = id.split('_');	
   	  $.ajax({
		url: baseURL +'dealingassistant/uploadOnEoffice',
		type:'get',
		data: {'application_number':idArray[1]},
		dataType:'json',
		success: function(jsonObj){
			if(jsonObj.status == true)
			{
				swal("Thank You!","Application Forward to NIPCCD Successfully!","success");
				location.reload(true);
			}
			else if(jsonObj.status == false)
			{
				swal("Error!",jsonObj.message,"error");
			}
		},
		error:function(responseText){
			swal("Error!","Some Error Occur While Forwarding","error");
		}		
	 }); 
   }
}
function perpareForPAC(id)
{
   if(id != "")
   {
   	 var idArray = id.split('_');	
   	  $.ajax({
		url: baseURL +'dealingassistant/perpareForPAC',
		type:'get',
		data: {'application_no':idArray[1],'ngo_id':idArray[2]},
		dataType:'json',
		success: function(jsonObj){
			if(jsonObj.status == true)
			{
				swal("Thank You!","Application Forward to NIPCCD Successfully!","success");
				location.reload(true);
			}
			else if(jsonObj.status == false)
			{
				swal("Error!",jsonObj.message,"error");
			}
		},
		error:function(responseText){
			swal("Error!","Some Error Occur While Forwarding","error");
		}		
	 }); 
   }
}
function forwardToNIPCCD(id)
{
   if(id != "")
   {
   	 var idArray = id.split('_');	
   	  $.ajax({
		url: baseURL +'dealingassistant/forwardToNIPCCD',
		type:'get',
		data: {'application_no':idArray[1],'ngo_id':idArray[2]},
		dataType:'json',
		success: function(jsonObj){
			if(jsonObj.status == true)
			{
				
				swal({
				  title: "Thank You!",
				  text: "Application Forward to NIPCCD Successfully!",
				  type: "success",
				  confirmButtonText: "OK",
				  },
				function(){
				  location.reload(true);
				});
				
			}
			else if(jsonObj.status == false)
			{
				swal("Error!",jsonObj.message,"error");
			}
		},
		error:function(responseText){
			swal("Error!","Some Error Occur While Forwarding","error");
		}		
	 }); 
   }
}
function forwardToState(id)
{
   if(id != "")
   {
   	 var idArray = id.split('_');	
   	  $.ajax({
		url: baseURL +'dealingassistant/forwardToState',
		type:'get',
		data: {'application_no':idArray[1],'ngo_id':idArray[2]},
		dataType:'json',
		success: function(jsonObj){
			if(jsonObj.status == true)
			{
				swal({
				  title: "Thank You!",
				  text: "Application Forward to State Successfully!",
				  type: "success",
				  confirmButtonText: "OK",
				  },
				function(){
				  location.reload(true);
				});
				
			}
			else if(jsonObj.status == false)
			{
				swal("Error!",jsonObj.message,"error");
			}
		},
		error:function(responseText){
			swal("Error!","Some Error Occur While Forwarding","error");
		}		
	 }); 
   }
}
function createAppraisalSlots()
{
	var ids = selected;
	if(selected.length > 0)
	{
		$.ajax({
			url: baseURL +'dealingassistant/createSlots',
			type:'get',
			data: {'applicationIds':ids},
			dataType:'json',
			success: function(jsonObj){
				if(jsonObj.status == true)
				{
					swal("Thank You!",jsonObj.message,"success");
					location.reload();
				}
				else if(jsonObj.status == false)
				{
					swal("Error!",jsonObj.message,"error");
				}
			},
			error:function(responseText){
				swal("Error!","Some Error Occur While Creating PAC","error");
			}		
		 });
	}
	else
	{
		swal("Error!","Please select at least one application.","error");
	}
}
/*file upload for swadhar part B*/

if(Controller != "home")
{	
	Dropzone.autoDiscover = false;
	Dropzone.options.swadharbdesign = {
		//alert(getParameterByName("aid"));	  
	    success: function(file, response){
	    
			var jsresp = JSON.parse(response);
			var url      = window.location.href; 
			var n = url.lastIndexOf("index.html");
			var pathtoredirect= url.substring(n);
			
	        if(jsresp.status == true){
				swal({
				  title: "Thank You!",
				  text: "Document Submitted Successfully!",
				  type: "success",
				  confirmButtonText: "OK",
				  },
				function(){
				  $('#swadharbdesignfile').hide();
                                  $('.modal-backdrop').hide();
                                  $('body').removeClass("modal-open");
                                 
                                  /*is document exist action start*/
                                $.ajax({
    type: "get",
    url: baseURL +'ngo/isdocumentExistsc',
    data: {"appId":getParameterByName("aid"),"docId":'1'},
    dataType:'text',
    success: function (data) {	
   //alert(data);
   if(data== "true")
    	{
    		$("#swadharb_design_fileId").show();
    		 $("#swadharb_design_fileId").attr("href", jsresp.file_path);
    		
    	}
    	
     }
    
    });
    /*is document exist action end*/
                                 
                                 
                                 
				});
			}
			else if(jsresp.status == false)
			{
				swal("Error!","Error In Uploading Try After Some Time.","error");
			}
	    },
	    error:function(responsetest,error,jqhr){
			console.log(responsetest);
			console.log(error);
		},
		complete:function(file){
			this.removeFile(file);
		},
	     params: {'aid':getParameterByName("aid")},
	    dictDefaultMessage:"Click / Drop here to upload files",
	    addRemoveLinks: true,
	    dictRemoveFile:"Remove",
	    maxFiles:1,
	      acceptedFiles: ".pdf",
	    maxFilesize:5,
	    parallelUploads:35
	}	
	
	$(function() {
	  /* Upload Profile Pic */
		$('#swadharbdesign').dropzone({ url: baseURL + "ngo/swadharbfile1",uploadMultiple:true,dictDefaultMessage:"Click / Drop here to upload files"});	
	});
}










//Research scheme
/*js for upload research scheme start*/
if(Controller != "home")
{	
	Dropzone.autoDiscover = false;
	Dropzone.options.researchprojectdirector = {
		//alert(getParameterByName("aid"));	  
	    success: function(file, response){
	    
			var jsresp = JSON.parse(response);
			var url      = window.location.href; 
			var n = url.lastIndexOf("index.html");
			var pathtoredirect= url.substring(n);
			
	        if(jsresp.status == true){
				swal({
				  title: "Thank You!",
				  text: "Document Submitted Successfully!",
				  type: "success",
				  confirmButtonText: "OK",
				  },
				function(){
				  //location.href = baseURL + "users"+pathtoredirect;
				   $('#research_project_director').hide();
                                  $('.modal-backdrop').hide();
                                  $('body').removeClass("modal-open");
                                  
                                   /*is document exist action start*/
                                $.ajax({
    type: "get",
    url: baseURL +'ngo/isdocumentExistsc',
    data: {"appId":getParameterByName("aid"),"docId":'2'},
    dataType:'text',
    success: function (data) {	
   //alert(data);
   if(data== "true")
    	{
    		$("#researchpdId").show();
    		 $("#researchpdId").attr("href", jsresp.file_path);
    		
    	}
    	
     }
    
    });
    /*is document exist action end*/
                                  
                                
				});
			}
			else if(jsresp.status == false)
			{
				swal("Error!","Error In Uploading Try After Some Time.","error");
			}
	    },
	    error:function(responsetest,error,jqhr){
			console.log(responsetest);
			console.log(error);
		},
	     params: {'aid':getParameterByName("aid")},
	    dictDefaultMessage:"Click / Drop here to upload files",
	    addRemoveLinks: true,
	    dictRemoveFile:"Remove",
	    maxFiles:1,
	    maxFilesize:3,
	    parallelUploads:35
	}	
	
	$(function() {
	  /* Upload Profile Pic */
		$('#researchprojectdirector').dropzone({ url: baseURL + "ngo/research_director_detail",uploadMultiple:true,dictDefaultMessage:"Click / Drop here to upload files"});	
	});
}



if(Controller != "home")
{	
	Dropzone.autoDiscover = false;
	Dropzone.options.estimateprojectbudget = {
		//alert(getParameterByName("aid"));	  
	    success: function(file, response){
	    
			var jsresp = JSON.parse(response);
			var url      = window.location.href; 
			var n = url.lastIndexOf("index.html");
			var pathtoredirect= url.substring(n);
			
	        if(jsresp.status == true){
				swal({
				  title: "Thank You!",
				  text: "Document Submitted Successfully!",
				  type: "success",
				  confirmButtonText: "OK",
				  },
				function(){
				  //location.href = baseURL + "users"+pathtoredirect;
				   $('#estimate_projectbudget').hide();
                                  $('.modal-backdrop').hide();
                                  $('body').removeClass("modal-open");
                                 
                                 
                                  /*is document exist action start*/
                                $.ajax({
    type: "get",
    url: baseURL +'ngo/isdocumentExistsc',
    data: {"appId":getParameterByName("aid"),"docId":'3'},
    dataType:'text',
    success: function (data) {	
   //alert(data);
   if(data== "true")
    	{
    		$("#researchprobudgetId").show();
    		 $("#researchprobudgetId").attr("href", jsresp.file_path);
    		
    	}
    	
     }
    
    });
    /*is document exist action end*/
                                 
                                 
				});
			}
			else if(jsresp.status == false)
			{
				swal("Error!","Error In Uploading Try After Some Time.","error");
			}
	    },
	    error:function(responsetest,error,jqhr){
			console.log(responsetest);
			console.log(error);
		},
	     params: {'aid':getParameterByName("aid")},
	    dictDefaultMessage:"Click / Drop here to upload files",
	    addRemoveLinks: true,
	    dictRemoveFile:"Remove",
	    maxFiles:1,
	    maxFilesize:60,
	    parallelUploads:35
	}	
	
	$(function() {
	  /* Upload Profile Pic */
		$('#estimateprojectbudget').dropzone({ url: baseURL + "ngo/estimatebudgetproject",uploadMultiple:true,dictDefaultMessage:"Click / Drop here to upload files"});	
	});
}




if(Controller != "home")
{	
	Dropzone.autoDiscover = false;
	Dropzone.options.researchcopyreg = {
		//alert(getParameterByName("aid"));	  
	    success: function(file, response){
	    
			var jsresp = JSON.parse(response);
			var url      = window.location.href; 
			var n = url.lastIndexOf("index.html");
			var pathtoredirect= url.substring(n);
			
	        if(jsresp.status == true){
				swal({
				  title: "Thank You!",
				  text: "Document Submitted Successfully!",
				  type: "success",
				  confirmButtonText: "OK",
				  },
				function(){
				  //location.href = baseURL + "users"+pathtoredirect;
				   $('#research_co_reg').hide();
                                  $('.modal-backdrop').hide();
                                  $('body').removeClass("modal-open");
                                
                                
                                 /*is document exist action start*/
                                $.ajax({
    type: "get",
    url: baseURL +'ngo/isdocumentExistsc',
    data: {"appId":getParameterByName("aid"),"docId":'4'},
    dataType:'text',
    success: function (data) {	
   //alert(data);
   if(data== "true")
    	{
    		$("#researchCoregId").show();
    		 $("#researchCoregId").attr("href", jsresp.file_path);
    		
    	}
    	
     }
    
    });
    /*is document exist action end*/
                                
                                
                                
                                
				});
			}
			else if(jsresp.status == false)
			{
				swal("Error!","Error In Uploading Try After Some Time.","error");
			}
	    },
	    error:function(responsetest,error,jqhr){
			console.log(responsetest);
			console.log(error);
		},
	     params: {'aid':getParameterByName("aid")},
	    dictDefaultMessage:"Click / Drop here to upload files",
	    addRemoveLinks: true,
	    dictRemoveFile:"Remove",
	    maxFiles:1,
	     acceptedFiles: ".pdf",
	    maxFilesize:60,
	    parallelUploads:35
	}	
	
	$(function() {
	  /* Upload Profile Pic */
		$('#researchcopyreg').dropzone({ url: baseURL + "ngo/researchregistrationcopy",uploadMultiple:true,dictDefaultMessage:"Click / Drop here to upload files"});	
	});
}



if(Controller != "home")
{	
	Dropzone.autoDiscover = false;
	Dropzone.options.researchannualreport = {
		//alert(getParameterByName("aid"));	  
	    success: function(file, response){
	    
			var jsresp = JSON.parse(response);
			var url      = window.location.href; 
			var n = url.lastIndexOf("index.html");
			var pathtoredirect= url.substring(n);
			
	        if(jsresp.status == true){
				swal({
				  title: "Thank You!",
				  text: "Document Submitted Successfully!",
				  type: "success",
				  confirmButtonText: "OK",
				  },
				function(){
				  //location.href = baseURL + "users"+pathtoredirect;
				  $('#research_annualrep').hide();
                                  $('.modal-backdrop').hide();
                                  $('body').removeClass("modal-open");
                                
                                
                                 /*is document exist action start*/
                                $.ajax({
    type: "get",
    url: baseURL +'ngo/isdocumentExistsc',
    data: {"appId":getParameterByName("aid"),"docId":'5'},
    dataType:'text',
    success: function (data) {	
   //alert(data);
   if(data== "true")
    	{
    		$("#researchArepId").show();
    		 $("#researchArepId").attr("href", jsresp.file_path);
    		
    	}
    	
     }
    
    });
    /*is document exist action end*/
                                
                                
                                
				  
				});
			}
			else if(jsresp.status == false)
			{
				swal("Error!","Error In Uploading Try After Some Time.","error");
			}
	    },
	    error:function(responsetest,error,jqhr){
			console.log(responsetest);
			console.log(error);
		},
	     params: {'aid':getParameterByName("aid")},
	    dictDefaultMessage:"Click / Drop here to upload files",
	    addRemoveLinks: true,
	    dictRemoveFile:"Remove",
	    maxFiles:1,
	     acceptedFiles: ".pdf",
	    maxFilesize:60,
	    parallelUploads:35
	}	
	
	$(function() {
	  /* Upload Profile Pic */
		$('#researchannualreport').dropzone({ url: baseURL + "ngo/researchreportannual",uploadMultiple:true,dictDefaultMessage:"Click / Drop here to upload files"});	
	});
}
//last five upload

if(Controller != "home")
{	
	Dropzone.autoDiscover = false;
	Dropzone.options.researchaudited = {
		//alert(getParameterByName("aid"));	  
	    success: function(file, response){
	    
			var jsresp = JSON.parse(response);
			var url      = window.location.href; 
			var n = url.lastIndexOf("index.html");
			var pathtoredirect= url.substring(n);
			
	        if(jsresp.status == true){
				swal({
				  title: "Thank You!",
				  text: "Document Submitted Successfully!",
				  type: "success",
				  confirmButtonText: "OK",
				  },
				function(){
				  //location.href = baseURL + "users"+pathtoredirect;
				   $('#research_audited').hide();
                                  $('.modal-backdrop').hide();
                                  $('body').removeClass("modal-open");
                                
                                
                                 /*is document exist action start*/
                                $.ajax({
    type: "get",
    url: baseURL +'ngo/isdocumentExistsc',
    data: {"appId":getParameterByName("aid"),"docId":'6'},
    dataType:'text',
    success: function (data) {	
   //alert(data);
   if(data== "true")
    	{
    		$("#researchAuitedId").show();
    		 $("#researchAuitedId").attr("href", jsresp.file_path);
    		
    	}
    	
     }
    
    });
    /*is document exist action end*/
                                
                                
                                
                                
				});
			}
			else if(jsresp.status == false)
			{
				swal("Error!","Error In Uploading Try After Some Time.","error");
			}
	    },
	    error:function(responsetest,error,jqhr){
			console.log(responsetest);
			console.log(error);
		},
	     params: {'aid':getParameterByName("aid")},
	    dictDefaultMessage:"Click / Drop here to upload files",
	    addRemoveLinks: true,
	    dictRemoveFile:"Remove",
	    maxFiles:1,
	     acceptedFiles: ".pdf",
	    maxFilesize:60,
	    parallelUploads:35
	}	
	
	$(function() {
	  /* Upload Profile Pic */
		$('#researchaudited').dropzone({ url: baseURL + "ngo/researchaudited",uploadMultiple:true,dictDefaultMessage:"Click / Drop here to upload files"});	
	});
}

if(Controller != "home")
{	
	Dropzone.autoDiscover = false;
	Dropzone.options.researcharticles = {
		//alert(getParameterByName("aid"));	  
	    success: function(file, response){
	    
			var jsresp = JSON.parse(response);
			var url      = window.location.href; 
			var n = url.lastIndexOf("index.html");
			var pathtoredirect= url.substring(n);
			
	        if(jsresp.status == true){
				swal({
				  title: "Thank You!",
				  text: "Document Submitted Successfully!",
				  type: "success",
				  confirmButtonText: "OK",
				  },
				function(){
				  //location.href = baseURL + "users"+pathtoredirect;
				  
				   $('#research_articles').hide();
                                  $('.modal-backdrop').hide();
                                  $('body').removeClass("modal-open");
                                
                                
                                 /*is document exist action start*/
                                $.ajax({
    type: "get",
    url: baseURL +'ngo/isdocumentExistsc',
    data: {"appId":getParameterByName("aid"),"docId":'7'},
    dataType:'text',
    success: function (data) {	
   //alert(data);
   if(data== "true")
    	{
    		$("#researchArticleId").show();
    		 $("#researchArticleId").attr("href", jsresp.file_path);
    		
    	}
    	
     }
    
    });
    /*is document exist action end*/
                                
				  
				});
			}
			else if(jsresp.status == false)
			{
				swal("Error!","Error In Uploading Try After Some Time.","error");
			}
	    },
	    error:function(responsetest,error,jqhr){
			console.log(responsetest);
			console.log(error);
		},
	     params: {'aid':getParameterByName("aid")},
	    dictDefaultMessage:"Click / Drop here to upload files",
	    addRemoveLinks: true,
	    dictRemoveFile:"Remove",
	    maxFiles:1,
	     acceptedFiles: ".pdf",
	    maxFilesize:60,
	    parallelUploads:35
	}	
	
	$(function() {
	  /* Upload Profile Pic */
		$('#researcharticles').dropzone({ url: baseURL + "ngo/researcharticles",uploadMultiple:true,dictDefaultMessage:"Click / Drop here to upload files"});	
	});
}

if(Controller != "home")
{	
	Dropzone.autoDiscover = false;
	Dropzone.options.researchofficebearers = {
		//alert(getParameterByName("aid"));	  
	    success: function(file, response){
	    
			var jsresp = JSON.parse(response);
			var url      = window.location.href; 
			var n = url.lastIndexOf("index.html");
			var pathtoredirect= url.substring(n);
			
	        if(jsresp.status == true){
				swal({
				  title: "Thank You!",
				  text: "Document Submitted Successfully!",
				  type: "success",
				  confirmButtonText: "OK",
				  },
				function(){
				  //location.href = baseURL + "users"+pathtoredirect;
				  
				  $('#research_office_bearers').hide();
                                  $('.modal-backdrop').hide();
                                  $('body').removeClass("modal-open");
                                
                                
                                 /*is document exist action start*/
                                $.ajax({
    type: "get",
    url: baseURL +'ngo/isdocumentExistsc',
    data: {"appId":getParameterByName("aid"),"docId":'8'},
    dataType:'text',
    success: function (data) {	
   //alert(data);
   if(data== "true")
    	{
    		$("#researchObearerId").show();
    		 $("#researchObearerId").attr("href", jsresp.file_path);
    		
    	}
    	
     }
    
    });
    /*is document exist action end*/
                                
                                
                                
				  
				});
			}
			else if(jsresp.status == false)
			{
				swal("Error!","Error In Uploading Try After Some Time.","error");
			}
	    },
	    error:function(responsetest,error,jqhr){
			console.log(responsetest);
			console.log(error);
		},
	     params: {'aid':getParameterByName("aid")},
	    dictDefaultMessage:"Click / Drop here to upload files",
	    addRemoveLinks: true,
	    dictRemoveFile:"Remove",
	    maxFiles:1,
	     acceptedFiles: ".pdf",
	    maxFilesize:60,
	    parallelUploads:35
	}	
	
	$(function() {
	  /* Upload Profile Pic */
		$('#researchofficebearers').dropzone({ url: baseURL + "ngo/researchofficebearers",uploadMultiple:true,dictDefaultMessage:"Click / Drop here to upload files"});	
	});
}

if(Controller != "home")
{	
	Dropzone.autoDiscover = false;
	Dropzone.options.researchaccountwork = {
		//alert(getParameterByName("aid"));	  
	    success: function(file, response){
	    
			var jsresp = JSON.parse(response);
			var url      = window.location.href; 
			var n = url.lastIndexOf("index.html");
			var pathtoredirect= url.substring(n);
			
	        if(jsresp.status == true){
				swal({
				  title: "Thank You!",
				  text: "Document Submitted Successfully!",
				  type: "success",
				  confirmButtonText: "OK",
				  },
				function(){
				  //location.href = baseURL + "users"+pathtoredirect;
				   $('#research_account_work').hide();
                                  $('.modal-backdrop').hide();
                                  $('body').removeClass("modal-open");
                                
                                 /*is document exist action start*/
                                $.ajax({
    type: "get",
    url: baseURL +'ngo/isdocumentExistsc',
    data: {"appId":getParameterByName("aid"),"docId":'9'},
    dataType:'text',
    success: function (data) {	
   //alert(data);
   if(data== "true")
    	{
    		$("#researchAworkId").show();
    		 $("#researchAworkId").attr("href", jsresp.file_path);
    		
    	}
    	
     }
    
    });
    /*is document exist action end*/
                                
				});
			}
			else if(jsresp.status == false)
			{
				swal("Error!","Error In Uploading Try After Some Time.","error");
			}
	    },
	    error:function(responsetest,error,jqhr){
			console.log(responsetest);
			console.log(error);
		},
	     params: {'aid':getParameterByName("aid")},
	    dictDefaultMessage:"Click / Drop here to upload files",
	    addRemoveLinks: true,
	    dictRemoveFile:"Remove",
	    maxFiles:1,
	     acceptedFiles: ".pdf",
	    maxFilesize:60,
	    parallelUploads:35
	}	
	
	$(function() {
	  /* Upload Profile Pic */
		$('#researchaccountwork').dropzone({ url: baseURL + "ngo/researchaccountwork",uploadMultiple:true,dictDefaultMessage:"Click / Drop here to upload files"});	
	});
}

if(Controller != "home")
{	
	Dropzone.autoDiscover = false;
	Dropzone.options.researchbiodata = {
		//alert(getParameterByName("aid"));	  
	    success: function(file, response){
	    
			var jsresp = JSON.parse(response);
			var url      = window.location.href; 
			var n = url.lastIndexOf("index.html");
			var pathtoredirect= url.substring(n);
			
	        if(jsresp.status == true){
				swal({
				  title: "Thank You!",
				  text: "Document Submitted Successfully!",
				  type: "success",
				  confirmButtonText: "OK",
				  },
				function(){
				  //location.href = baseURL + "users"+pathtoredirect;
				   $('#research_biodata').hide();
                                  $('.modal-backdrop').hide();
                                  $('body').removeClass("modal-open");
                                
                                
                                 /*is document exist action start*/
                                $.ajax({
    type: "get",
    url: baseURL +'ngo/isdocumentExistsc',
    data: {"appId":getParameterByName("aid"),"docId":'10'},
    dataType:'text',
    success: function (data) {	
   //alert(data);
   if(data== "true")
    	{
    		$("#researchBiodataId").show();
    		 $("#researchBiodataId").attr("href", jsresp.file_path);
    		
    	}
    	
     }
    
    });
    /*is document exist action end*/
                                
                                   
				});
			}
			else if(jsresp.status == false)
			{
				swal("Error!","Error In Uploading Try After Some Time.","error");
			}
	    },
	    error:function(responsetest,error,jqhr){
			console.log(responsetest);
			console.log(error);
		},
	     params: {'aid':getParameterByName("aid")},
	    dictDefaultMessage:"Click / Drop here to upload files",
	    addRemoveLinks: true,
	    dictRemoveFile:"Remove",
	    maxFiles:1,
	     acceptedFiles: ".pdf",
	    maxFilesize:60,
	    parallelUploads:35
	}	
	
	$(function() {
	  /* Upload Profile Pic */
		$('#researchbiodata').dropzone({ url: baseURL + "ngo/researchbiodata",uploadMultiple:true,dictDefaultMessage:"Click / Drop here to upload files"});	
	});
}

if(Controller != "home")
{	
	Dropzone.autoDiscover = false;
	Dropzone.options.researchproposal = {
		//alert(getParameterByName("aid"));	  
	    success: function(file, response){
	    
			var jsresp = JSON.parse(response);
			var url      = window.location.href; 
			var n = url.lastIndexOf("index.html");
			var pathtoredirect= url.substring(n);
			
	        if(jsresp.status == true){
				swal({
				  title: "Thank You!",
				  text: "Document Submitted Successfully!",
				  type: "success",
				  confirmButtonText: "OK",
				  },
				function(){
				  //location.href = baseURL + "users"+pathtoredirect;
				   $('#seminar_research_proposal').hide();
                                  $('.modal-backdrop').hide();
                                  $('body').removeClass("modal-open");
                                
                                /*is document exist action start*/
                                $.ajax({
    type: "get",
    url: baseURL +'ngo/isdocumentExistsc',
    data: {"appId":getParameterByName("aid"),"docId":'11'},
    dataType:'text',
    success: function (data) {	
   //alert(data);
   if(data== "true")
    	{
    		$("#seminarRproposalId").show();
    		 $("#seminarRproposalId").attr("href", jsresp.file_path);
    		
    	}
    	
     }
    
    });
    /*is document exist action end*/
                                
                                
                                
                                
				});
			}
			else if(jsresp.status == false)
			{
				swal("Error!","Error In Uploading Try After Some Time.","error");
			}
	    },
	    error:function(responsetest,error,jqhr){
			console.log(responsetest);
			console.log(error);
		},
	     params: {'aid':getParameterByName("aid")},
	    dictDefaultMessage:"Click / Drop here to upload files",
	    addRemoveLinks: true,
	    dictRemoveFile:"Remove",
	    maxFiles:1,
	    acceptedFiles: ".pdf",
	    maxFilesize:60,
	    parallelUploads:35
	}	
	
	$(function() {
	  /* Upload Profile Pic */
		$('#researchproposal').dropzone({ url: baseURL + "ngo/researchproposal",uploadMultiple:true,dictDefaultMessage:"Click / Drop here to upload files"});	
	});
}

function checkemptydocname(id)
{
    
   
   var parts = id.split('-', 2);
       divid = parts[0];
       docids= parts[1];
  
    var documentname=$('#'+divid).val();
    var appId=$('#application_number').val();
    
    
    if(documentname == "")
    {
        $('#commonfileupload').hide();
        
    }
    else
    {
        $('#commonfileupload').show();
        
    }   
    
     $.ajax({
        type: "POST",
        url: baseURL+"ngo/additionalDocName", 
        data: "documentname="+documentname+"&docid="+docids+"&appId="+appId,

            success: function(data) 
            {

            }
        });
	   
}
function showthestatus()
{
    
    if($("#projectApprovalStatus1").prop("checked", true))
    {
        $('.nipccdstatusupdate').show();
        
    }   
    if($("#projectApprovalStatus2").prop("checked", true))
    {
        $('.nipccdstatusupdate').hide();
        
    }
}

//Get Refresh Captcha
function getRefreshCaptcha()
{
    $.ajax({
        url: baseURL +'home/getRefreshCaptcha',
        type:'post',
        data: {hdnCap:'ngoCaptch',csrf_test_name:CH},
        success: function(obj)
        {
            if(obj == 'Error')
            {
                swal("Error!","Some Error Occur While Forwarding","error");
            }
            else
            {
                $('.ngoCaptcha').html(obj);
            }
        },
        error:function(){
            swal("Error!","Some Error Occur While Forwarding","error");
        }
    });
}

//Get Generate Password
function getPass(object=""){
    var value = '';
    
    if(object == ''){
        value = $('#password').val();
        value = $.trim(value);
    }else{
        value = $('#'+object).val();
        value = $.trim(value);
    }

    if(value != '')
    {
        value = salt+md5(value)+md5(commonSalt);
        if(object == ''){
            $('#password').val(md5(value));
        }else{
            $('#'+object).val(value);
        }
    }
}

function getChangePass(){
    var error = 0;
    var oldvalue = $('#old_password').val();
    oldvalue = $.trim(oldvalue);
    $('.old_password').text('');

    var newvalue = $('#newpassword').val();
    newvalue = $.trim(newvalue);
    $('.newpassword').text('');

    var cvalue = $('#cpassword').val();
    cvalue = $.trim(cvalue);
    $('.cpassword').text('');

    if(oldvalue != ''){
        oldvalue = salt+md5(oldvalue)+md5(commonSalt);
        $('#old_password').val(md5(oldvalue));
    }else{
        $('.old_password').text('Please enter old password.');
        $('#old_password').focus();
        error++;
    }

    if(newvalue == ''){
        $('.newpassword').text('Please enter new password.');
        $('#newpassword').focus();
        error++;
    }

    if(cvalue != ''){
        if(cvalue !== newvalue){
            $('.cpassword').text('Confirm password does not match.');
            $('#cpassword').val('').focus();
            error++;
        }else{
            $('#newpassword').val(md5(newvalue)+md5(commonSalt));
            $('#cpassword').val(md5(cvalue)+md5(commonSalt));
        }
    }else{
        $('.cpassword').text('Please enter confirm password.');
        $('#cpassword').focus();
        error++;
    }
    
    if(error > 0)
    {
        return false;
    }
    else
    {
        //$('#xhr').val(newvalue);
        return true;
    }
}

function validateExpenditure()
{
    if($('.expen').length > 0)
    {
        var expenditure = $('.expen').val();
        expenditure = $.trim(expenditure);
        expenditure = parseInt(expenditure);
        
        var grant = $('.grant').val();
        grant = $.trim(grant);
        grant = parseInt(grant);
        
        var proposed = $('.proposed').val();
        proposed = $.trim(proposed);
        proposed = parseInt(proposed);
        
        var grant_proposed_sum = grant + proposed;
        
        if(grant_proposed_sum > 0)
        {
            if(grant_proposed_sum > expenditure){
                alert('Expenditure amount can not be less than total of grant and proposed amount!');
                $('.expen').focus();
                return false;
            }
        }
        
        if(grant >= expenditure)
        {
            alert('Grant amount can not be greater than or equal to expenditure amount!');
            $('.grant').focus();
            return false;
        }
    }
}

function getValidateAdditional()
{
    if($('.addocument').length > 0){
        
        var document_id='';
        var document_vl='';
        var document_ms='';
        
        $('.addocument').each(function(){
            
            document_vl = this.value;
            document_vl = $.trim(document_vl);
            document_id = '';
            
            if(document_vl != ''){
                document_id = this.id;
                document_id = document_id.split('_');
                document_id = document_id[1];
                
                document_id = '#additional_documents'+document_id;
                
                if($(document_id).attr('href') == 'javascript:void();'){
                    
                    if($.trim($(this).parent('td').siblings('td:first').text()) == ''){
                        document_ms += 'Additional documents '+document_vl+' are required. \n\r';
                    }else{
                        document_ms += 'Additional documents '+$(this).parent('td').siblings('td:first').text().replace('.','')+' are required. \n\r';
                    }
                }
            }
        });
        
        if(document_ms != ''){
            alert(document_ms);
            return false;
        }else{
            return true;
        }
    }
}

function getDistrictregisterreg(id)
{
   
    $.ajax({
        type: "get",
        url: baseURL + 'Users/getDistrict_univ',
        data: 'stateId=' + id+'&'+token_name+'='+csrf_token,
        dataType: 'json',
            success: function (jsondata) {
				
            if (jsondata.status == true)
            {
                var districts = "";
                districts += "<option value=''>Select District</option>";
                for (var i = 0; i < jsondata.data.length; i++)
                {
                    districts += "<option value='" + jsondata.data[i].district_id + "'>" + jsondata.data[i].district_name + "</option>";
                }
                $("#district").html(districts);
            }
        },
		sending:function(file, xhr, formData){
            formData.append(token_name, csrf_token);  
            },
        error: function (jqXHR, text, error) {

        }
    });
}

function getRefreshCaptcha_univ()
{
	//alert("m in!!");
    $.ajax({
        url: baseURL +'Users/getRefreshCaptcha_register',
        type:'post',
        data: {hdnCap:'ngoCaptch'},//,csrf_test_name:CH
        success: function(obj)
        {
            if(obj == 'Error')
            {
                swal("Error!","Some Error Occur While Forwarding","error");
            }
            else
            {
                $('.ngoCaptcha').html(obj);
            }
        },
        error:function(){
            swal("Error!","Some Error Occur While Forwarding","error");
        }
    });
}


function validateEmailidreg(uesremail)
{
    var email = uesremail;
    email = $.trim(email);

    var pattern = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/;
    if (pattern.test(email))
    {
        return true;
    } else
    {
        alert('Please Enter valid email');
        return false;
    }
}


function getConfirmPassreg() {
     
    var passwordvalue = $('#newpassword').val();
    passwordvalue = $.trim(passwordvalue);

    var confirmpasswordvalue = $('#cpassword').val();
    confirmpasswordvalue = $.trim(confirmpasswordvalue);

    if (passwordvalue != '')
    {
        passwordvalue = md5(passwordvalue);
        $('#newpassword').val(salt + '@#1' + passwordvalue);
    }
   if (confirmpasswordvalue != '')
    {
        confirmpasswordvalue = md5(confirmpasswordvalue);
        $('#cpassword').val(salt + '@#1' + confirmpasswordvalue);
    }
}

//Validate Ngo
function validate_ngo(){
    //Hide error span
    $('.error_span').hide();
    
    var aayog = $('#niti_aayog_id').val();
    aayog = $.trim(aayog);
    
    var state = $('#state').val();
    state = $.trim(state);
    
    if(aayog == '' && state == ''){
        $('#error_aayog').text('Please choose at least on option to filter.').show();
        $('#niti_aayog_id').focus();
        return false;
    }
    return true;
}

//Validate application
function validate_application(){
    //Hide error span
    $('.error_span').hide().text('');
    
    var app_no = $('#app_no').val();
    app_no = $.trim(app_no);
    
    var scheme = $('#scheme_filter').val();
    scheme = $.trim(scheme);
    
    var aayog = $('#niti_aayog_id').val();
    aayog = $.trim(aayog);
    
    var state = $('#state').val();
    state = $.trim(state);
    
    var start_date = $('#start_date').val();
    start_date = $.trim(start_date);
    
    var end_date = $('#end_date').val();
    end_date = $.trim(end_date);
    if(app_no == '' && scheme == '' && aayog == '' && state == '' && start_date == '' && end_date == ''){
        $('#error_application').text('Please choose at least on option to filter.').show();
        $('#app_no').focus();
        return false;
    }
    return true;
}
package com.wcd.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wcd.dao.IUserDao;

import model.User;
@Service
public class UserServiceImpl implements IUserService{
	private IUserDao userDao;
	@Autowired
		public void setNgoDao(IUserDao userDao) {
	    this.userDao = userDao;
	}
		
	@Override
	public void addUser(User n) {
		this.userDao.addUser(n);
		
	}

	@Override
	public boolean verifyUser(String email, String password) {
		return this.userDao.verifyUser(email, password);
	}

	@Override
	public User getUserDetails(int userDetailsId) {
		// TODO Auto-generated method stub
		return this.userDao.getUserDetails(userDetailsId);
	}

}

create table Ngo (id number primary key,uuid varchar2(30),name varchar2(30),userType varchar2(30),name varchar2(30),
address varchar2(30),pincode number(10),email varchar2(30),mobileNo number(10),password varchar2(30));

create table Course(courseId number primary key,courseName varchar2(30),
courseDescription varchar2(30),courseDuration number(10),courseTiming varchar2(30),courseLocation varchar2(30));